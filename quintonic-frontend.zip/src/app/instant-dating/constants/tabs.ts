import { ITabs } from 'src/app/shared/interfaces/ui';

export const TABS: ITabs[] = [
  {
    title: 'RENCONTREZ',
    selected: false,
    route: '/meetup/game',
  },
  {
    title: "ILS/ELLES M'ONT CHOISI",
    selected: false,
    route: '/meetup/half-matches',
  },
  {
    title: 'VOUS MATCHEZ',
    selected: false,
    route: '/meetup/matches',
  },
];
