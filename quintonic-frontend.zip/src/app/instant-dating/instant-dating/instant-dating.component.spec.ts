import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantDatingComponent } from './instant-dating.component';

describe('InstantDatingComponent', () => {
  let component: InstantDatingComponent;
  let fixture: ComponentFixture<InstantDatingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstantDatingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstantDatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
