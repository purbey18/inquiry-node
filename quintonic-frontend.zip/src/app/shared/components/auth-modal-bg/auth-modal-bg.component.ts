import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-auth-modal-bg',
  templateUrl: './auth-modal-bg.component.html',
  styleUrls: ['./auth-modal-bg.component.scss']
})
export class AuthModalBgComponent implements OnInit {
  @Input() title = '';
  @Output() close: EventEmitter<any> = new EventEmitter();
  @Input() hideClose: boolean = true;
  constructor() { }

  ngOnInit(): void {
  }

}
