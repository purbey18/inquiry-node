import { Component, OnInit } from '@angular/core';
import { FavoriteCity } from 'src/app/shared/interfaces/common';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';

@Component({
  selector: 'app-regional-groups',
  templateUrl: './regional-groups.component.html',
  styleUrls: ['./regional-groups.component.scss'],
})
export class RegionalGroupsComponent implements OnInit {
  cities: FavoriteCity[] = [];
  constructor(private ActivityService: ActivityService) { }

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.ActivityService.favoriteCity().subscribe((res) => {
      console.log(res);
      this.cities = res;
    });
  }
}
