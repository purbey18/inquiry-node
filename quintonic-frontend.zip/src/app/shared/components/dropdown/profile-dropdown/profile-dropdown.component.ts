import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IMyFriends } from 'src/app/shared/interfaces/profile';
import { HeaderService } from 'src/app/shared/services/header/header.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';

@Component({
  selector: 'app-profile-dropdown',
  templateUrl: './profile-dropdown.component.html',
  styleUrls: ['./profile-dropdown.component.scss'],
})
export class ProfileDropdownComponent implements OnInit {
  @Input() friendDetail!: IMyFriends;

  constructor(
    private modalService: ModalService,
    private translate: TranslateService,
    private headerService: HeaderService
  ) { }

  ngOnInit(): void {
  }

  removeFriend() {
    const title = this.translate.instant(
      'friends.modals.confirmRemoveFriend.title',
      { user_name: this.friendDetail.user_name }
    );
    const message = this.translate.instant(
      'friends.modals.confirmRemoveFriend.contentF'
    );
    const icon = 'remove-friend-icon'
    this.modalService
      .confirmation(title, message, icon)
      .then((res) => {
        this.headerService
          .removeFriend(this.friendDetail.id)
          .subscribe((res) => {
            console.log(res);
          });
      })
      .catch(() => { console.log('error') });
  }

  blockFriend() {
    const title = this.translate.instant(
      'friends.modals.confirmBlockUser.title',
      { user_name: this.friendDetail.user_name }
    );
    const message = this.translate.instant(
      'friends.modals.confirmBlockUser.contentF'
    );
    const icon = 'stop-icon';
    this.modalService
      .confirmation(title, message, icon)
      .then((res) => {
        this.headerService
          .blockFriend(this.friendDetail.id)
          .subscribe((res) => {
            console.log(res);
          });
      })
      .catch(() => { console.log('error') });
  }
}
