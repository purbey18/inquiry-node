import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-posted-by',
  templateUrl: './posted-by.component.html',
  styleUrls: ['./posted-by.component.scss']
})
export class PostedByComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
