import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { ISuggestedPicture } from '../../interface/interface';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
@Component({
  selector: 'app-step-three',
  templateUrl: './step-three.component.html',
  styleUrls: ['./step-three.component.scss']
})
export class StepThreeComponent implements OnInit {
  suggestedPicList: ISuggestedPicture[] = [];
  imageChangedEvent: any = '';
  previewImage = false;
  croppedImage: any = '';
  @Output() saveToDraft: EventEmitter<any> = new EventEmitter();
  @Output() publishEvent: EventEmitter<any> = new EventEmitter();
  cover_picture = -1;
  isCropperStarted = false;
  isSubmitted = false;
  constructor(
    public modalService: ModalService,
    public activitySerive: ActivityService,
    private utilityService: UtilityService
  ) { }

  ngOnInit(): void {
    this.getSuggestedPictures(0)
  }

  getSuggestedPictures(themeId: number) {
    this.activitySerive.suggestedPictures(2).subscribe((res) => {
      this.suggestedPicList = res
    })
  }

  openChoosePhoto() {
    this.modalService.choosePhoto()
  }

  selectAlbumImage(id: number) {
    this.cover_picture = id;
  }

  doPublishEvent() {
    let data = {};
    if (this.cover_picture !== -1) {
      // selected from cover
      data = {'cover_picture[suggested_picture_id]': this.cover_picture, publish: true};
    } else if (this.croppedImage) {
      // from computer
      data = {'cover_picture[picture_file]': this.utilityService.dataURIToBlob(this.croppedImage), publish: true};      
    }
    this.isSubmitted = true;
    this.publishEvent.emit({data});
  }
  doSaveToDraft() {
    this.saveToDraft.emit({data: {'cover_picture[suggested_picture_id]': this.cover_picture}});
  }
  handle(e: any) {
    this.cover_picture = -1;
    this.imageChangedEvent = e;
    this.isCropperStarted = true;
    
  }
  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }

}
