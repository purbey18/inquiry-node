import { Component, OnInit } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IForumDiscussion, IUser } from 'src/app/shared/interfaces/common';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { IComments } from '../interface/interface';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
import { TranslateService } from '@ngx-translate/core';
import { ValidationService } from 'src/app/shared/services/validations/validations.sevice';
@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss'],
})
export class DetailsComponent implements OnInit {
  forum!: IForumDiscussion;
  filterForm: FormGroup;
  editDiscussionForm: FormGroup;
  discussionId!: number;
  commentsList: IComments[] = [];
  responseText: string = '';
  commentText: string = '';
  showInput: boolean = false;
  totalItems: number = 0;
  commentId!: string;
  showOtherComments: boolean = false;
  commentsListId!: number;
  user!: IUser;
  editMode: boolean = false;
  isSubmitted: boolean = false;

  constructor(
    private fb: FormBuilder,
    private modalService: ModalService,
    private forumService: ForumService,
    private route: ActivatedRoute,
    private utilService: UtilityService,
    private startupService: StartupService,
    private translate: TranslateService,
    private router: Router,
    private validationService: ValidationService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1, []),
      per_page: new FormControl(15, []),
    });
    this.editDiscussionForm = this.fb.group({
      body: ['', [this.validationService.requiredValidator()]],
      title: ['', [this.validationService.requiredValidator()]],
    });
  }

  ngOnInit(): void {
    this.details();
    this.user = this.startupService.getUser();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.editDiscussionForm.controls;
  }

  details() {
    this.route.paramMap.subscribe((params) => {
      const slug = params.get('discussion');
      this.forumService.discussionDetails(slug).subscribe((res) => {
        this.forum = res;
        this.discussionId = res.id;
        this.comments(res.id);
      });
    });
  }

  comments(id: number) {
    const query = this.utilService.serialize(this.filterForm.value);
    this.forumService.comments(id, query).subscribe((res) => {
      this.totalItems = res.headers.get('x-total');
      this.commentsList = res.body;

      this.commentsList.forEach((c, index) => {
        const allComment: any = [];
        this.getComments(index, c, allComment, (res: any) => {
          this.commentsList[index].allComments = res.reverse();
        });
      });
    });
  }

  getComments(index: number, c: IComments, allComment: any, callback: any) {
    if (c.parent) {
      allComment.push(c.parent.body);
      this.getComments(index + 1, c.parent, allComment, callback);
    } else {
      callback(allComment);
    }
  }

  displayChatModal() {
    this.modalService.createChatModel();
  }

  publishComment(id: number) {
    this.forumService.addComment(id, this.commentText).subscribe((res) => {
      this.commentText = '';
      this.comments(id);
    });
  }

  response(id: number) {
    this.forumService.respond(id, this.responseText).subscribe((res) => {
      this.responseText = '';
      this.commentId = '';
      this.comments(this.discussionId);
    });
  }

  deleteComment(id: number) {
    const title = this.translate.instant('shared.buttons.delete.title');
    const message = '';
    const icon = 'trash-icon';
    this.modalService.confirmation(title, message, icon).then((res) => {
      this.forumService.deleteComment(id).subscribe((res) => {
        this.comments(this.discussionId);
      });
    });
  }

  updatePagination(e: any) {
    this.filterForm.get('page')?.setValue(e);
    this.comments(this.discussionId);
  }

  addFavourite(discussion_id: number) {
    this.forumService
      .addFavoritesDiscussion({ discussion_id })
      .subscribe(() => {
        this.details();
      });
  }

  removeFavourite(discussion_id: number) {
    this.forumService.removeFavoriteDiscussion(discussion_id).subscribe(() => {
      this.details();
    });
  }

  reportAbusive() {
    this.modalService.abusiveContent();
  }

  submitDiscussionEdit() {
    if (!this.editDiscussionForm.valid) return;
    this.isSubmitted = true;
    this.forumService
      .edit_chat(this.discussionId, this.editDiscussionForm.value)
      .subscribe((res) => {
        this.details();
        this.editMode = false;
      });
  }

  deleteDiscussion() {
    const title = this.translate.instant('shared.buttons.delete.title');
    const message = '';
    const icon = 'trash-icon';
    this.modalService
      .confirmation(title, message, icon)
      .then((res) => {
        this.forumService.delete_chat(this.discussionId).subscribe((res) => {
          this.router.navigateByUrl('/forum');
        });
      })
      .catch(() => console.log('Error'));
  }

  changeEditMode() {
    this.editMode = true;
    this.editDiscussionForm.patchValue({
      body: this.forum.body,
      title: this.forum.title,
    });
  }

  receiveResponse(event: any) {
    this.responseText = event;
  }

  receiveComment(event: any) {
    this.commentText = event;
  }
}
