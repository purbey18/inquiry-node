import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { ITabs } from 'src/app/shared/interfaces/ui';


@Component({
  selector: 'app-custom-tabs',
  templateUrl: './custom-tabs.component.html',
  styleUrls: ['./custom-tabs.component.scss']
})
export class CustomTabsComponent implements OnInit {
  @Input() tabs: ITabs[] = [];
  @Output() tabSelected: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  tabClicked(e: any) {
    this.tabs.map(t => t.selected = false);
    e.selected = true;
    console.log(e);
    
    this.tabSelected.emit(e);
  }

}
