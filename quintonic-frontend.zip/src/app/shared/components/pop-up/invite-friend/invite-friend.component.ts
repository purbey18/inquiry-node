import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-invite-friend',
  templateUrl: './invite-friend.component.html',
  styleUrls: ['./invite-friend.component.scss'],
})
export class InviteFriendComponent implements OnInit {
  inviteFriendForm: FormGroup;
  constructor() {
    this.inviteFriendForm = new FormGroup({
      title: new FormControl('',),
    });
  }

  ngOnInit(): void {}
}
