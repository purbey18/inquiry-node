export interface IPageInfoBlock {
    title: string;
    description: string;
    image: string;
    btnText: string;
    alt: string;
    tooltip: string;
    class: string;
    link: string;
}

export interface Data {
    age: number;
    avatar?: any;
    biography?: any;
    city: string;
    created_at: Date;
    distance?: any;
    gender: string;
    id: number;
    mood?: any;
    slug: string;
    updated_at: Date;
    user_name: string;
    mutual_hobbies: any[];
    hobbies: any[];
    loves?: any;
    hates?: any;
    looking_for?: any;
    is_premium: boolean;
    confirmed: boolean;
    birth_date: string;
    first_name: string;
    last_name?: any;
    email: string;
    profile_completed_at?: any;
    password_reset_pending: boolean;
    relationship?: any;
    ambassed_favorite_city?: any;
    favorite_books: any[];
    favorite_movies: any[];
    favorite_shows: any[];
    current_subscription?: any;
}

export interface ISignIn {
    data: Data;
    success: Boolean;
}