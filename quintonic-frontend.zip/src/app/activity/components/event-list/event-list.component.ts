import { Component, Input } from '@angular/core';
import { IActivity } from '../../interface/interface';
import { IUser } from 'src/app/shared/interfaces/common';
import { StartupService } from 'src/app/shared/services/startup/startup.service';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss']
})
export class EventListComponent {
  @Input() activity!: IActivity;  
  user!: IUser;
  constructor(private startupService: StartupService) {
    this.user = this.startupService.getUser();
  }

}
