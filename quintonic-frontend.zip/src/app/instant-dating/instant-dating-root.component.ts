import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instant-dating-root',
  templateUrl: './instant-dating-root.component.html',
  styleUrls: ['./instant-dating-root.component.scss']
})
export class InstantDatingRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
