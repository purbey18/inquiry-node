import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { IUser } from 'src/app/shared/interfaces/common';
import { StartupService } from 'src/app/shared/services/startup/startup.service';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss']
})
export class AdvanceSearchComponent implements OnInit {
  advanceFilter = {
    title: '',
    commercial: '',
    whichActivities: {
      attending: false,
      organizing: false,
      waiting_list: false,
      interested: false,
      upcoming: false
    }
  }
  @Output() advanceFilterUpdated: EventEmitter<any> = new EventEmitter();
  user!: IUser;
  constructor(
    private startupService: StartupService
  ) {}

  ngOnInit(): void {
    this.user = this.startupService.getUser();
  }

  doAdvanceSearch() {
    console.log(this.advanceFilter);
    this.advanceFilterUpdated.emit(this.advanceFilter);
  }
}
