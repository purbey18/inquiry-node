import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-root',
  templateUrl: './member-root.component.html',
  styleUrls: ['./member-root.component.scss']
})
export class MemberRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
