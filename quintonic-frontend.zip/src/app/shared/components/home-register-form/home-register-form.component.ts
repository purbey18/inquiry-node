import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { Options } from 'ngx-google-places-autocomplete/objects/options/options';
import { Subject, Subscription, fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ModalService } from '../../services/modal/modal.service';
import { environment } from 'src/environments/environment';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../../services/auth/auth.service';
import { APP } from '../../constant/app.constant';
import { ValidationService } from '../../services/validations/validations.sevice';
@Component({
  selector: 'app-home-register-form',
  templateUrl: './home-register-form.component.html',
  styleUrls: ['./home-register-form.component.scss']
})
export class HomeRegisterFormComponent implements OnInit {
  @Input() class = '';
  options: Options = new Options({
    types: ['(cities)'],
    componentRestrictions: { country: 'FR' }
  });

  cityName: any;
  myInput: any;
  registerForm: FormGroup;
  years = Array.from({ length: 56 }, (_, i) => 1978 - i);
  months = Array.from({ length: 12 }, (_, i) => ({ name: new Date(2022, i).toLocaleString('default', { month: 'long' }), number: i + 1 }));
  dates = Array.from({ length: 31 }, (_, i) => i + 1);
  errorMessage: string = '';
  isSubmitted: boolean = false;

  fieldRequired = MESSAGE.COMMON.fieldRequired;
  invalidEmail = MESSAGE.AUTH.invalidEmail;
  passwordMinlength = MESSAGE.AUTH.passwordMinLength;
  nameMinLength = MESSAGE.AUTH.nameMinLength;
  emailAlreadyInUse = MESSAGE.AUTH.emailAlreadyInUse;
  isLoading = false;

  checkEmailModelChanged: Subject<any> = new Subject<any>();
  checkEmailModelChangesSubscription!: Subscription; 
  chckId = Math.random() + '_agree';
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private homeService: HomeService,
    private modalService: ModalService,
    private activeModal: NgbActiveModal,
    private auth: AuthService,
    private validationService: ValidationService
  ) {
    this.registerForm = this.fb.group({
      email: ['', [
        this.validationService.requiredValidator(),
        this.validationService.emailValidator,
        this.validationService.maxlengthValidator('email', 320)
      ]],
      password: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.minlengthValidator('password', 8),
        ],
      ],
      first_name: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.minlengthValidator('first name', 3),
          this.validationService.maxlengthValidator('first name', 16)
        ]
      ],
      looking_for: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      date: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      month: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      year: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      city: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      newsletter_optin: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      gender: [
        '',
        [
          this.validationService.requiredValidator()
        ]
      ],
      confirm_success_url: [environment.callbackUrl],
      config_name: ['default']
    });

    // Update valid dates when month changes
    this.registerForm.get('month')!.valueChanges.subscribe((month: number) => {
      const daysInMonth = new Date(this.registerForm.get('year')!.value, month, 0).getDate();
      const validDates = Array.from({ length: daysInMonth }, (_, i) => i + 1);
      this.registerForm.patchValue({ date: validDates.includes(Number(this.registerForm.get('date')!.value)) ? this.registerForm.get('date')!.value : '' });
      this.dates = validDates
    });

    this.checkEmailModelChangesSubscription = this.checkEmailModelChanged
    .pipe(
      debounceTime(1000),
      distinctUntilChanged()
    )
    .subscribe(query => {
      console.log();
      this.homeService.validateEmail(query.target.value).subscribe(
        {
          next: res => {
            if (!res.isValid) {
              this.registerForm.get('email')?.setErrors({ emailExist: MESSAGE.AUTH.emailAlreadyInUse });
            } else {
              this.registerForm.get('email')?.setErrors(null);
            }
          },
          error: err => {
            console.log(err)
          }
        }
      )
    });

  }

  ngOnInit(): void {
  }

  handleAddressChange(address: any) {
    this.registerForm.get('city')?.setValue(address.formatted_address);
  }

  get f(): { [key: string]: AbstractControl } {
    return this.registerForm.controls;
  }

  // validateEmail(event: any) {
  //   if (this.registerForm.get('email')?.errors === null) {
  //     const email = event.target.value
  //     fromEvent(document, 'input')
  //       .pipe(debounceTime(1000))
  //       .subscribe(() => {          
        // });
  //   }
  // }

  registerSubmit() {
    if (!this.registerForm.valid || this.errorMessage) {
      return;
    }
    this.isSubmitted = true
    const { date, month, year } = this.registerForm.value;
    this.registerForm.value.birth_date = `${year}-${month}-${date}`;

    this.homeService.register(this.registerForm.value).subscribe({
      next: res => {
        this.isSubmitted = false;
        if (res.body.status === 'success') {
          this.activeModal.close();
          this.auth.setValue(APP.COOKIE.ACCESS_TOKEN, res.headers.get(APP.COOKIE.ACCESS_TOKEN));
          this.auth.setValue(APP.COOKIE.CLIENT, res.headers.get(APP.COOKIE.CLIENT));
          this.auth.setValue(APP.COOKIE.UID, res.headers.get(APP.COOKIE.UID));
          this.router.navigateByUrl('/groupes/activites');
          this.modalService.finalizeRegistration(res.body.data.email);
        }
      },
      error: err => {
        console.log(err);
        this.isSubmitted = false;
      }
    })
  }

  ngOnDestroy() {
    this.checkEmailModelChangesSubscription.unsubscribe();
  }
}
