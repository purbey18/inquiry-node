import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { FavoriteCity } from 'src/app/shared/interfaces/common';

@Component({
  selector: 'app-your-favorite-cities',
  templateUrl: './your-favorite-cities.component.html',
  styleUrls: ['./your-favorite-cities.component.scss']
})
export class YourFavoriteCitiesComponent implements OnInit {

  favCities: FavoriteCity[] = [];
  constructor(
    private forumService: ForumService,
    private modalService: ModalService
  ) { }

  ngOnInit(): void {
    this.favoriteCity()
  }

  favoriteCity() {
    this.forumService.favoriteCities().subscribe((res: FavoriteCity[]) => {
      this.favCities = [...new Map(res.map(city => [city.id, city])).values()];
    })
  }

  openAddCityModal() {
    this.modalService.addFavCityModal();
  }

  openDeleteCityModal() {
    this.modalService.deleteFavCityModal()
  }
}
