import { Component, OnInit } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { IForumMainListing } from '../interface/interface';
import { FavoriteCity } from 'src/app/shared/interfaces/common';
@Component({
  selector: 'app-forum',
  templateUrl: './forum.component.html',
  styleUrls: ['./forum.component.scss'],
})
export class ForumComponent implements OnInit {

  forums: IForumMainListing[] = [];
  favCities: FavoriteCity[] = [];
  constructor(
    private forumService: ForumService,
    private modalService: ModalService
  ) { }

  ngOnInit(): void {
    this.load();
    this.favoriteCity()
  }

  load() {
    this.forumService.themes().subscribe((res) => {
      this.forums = res;
    });
  }

  displayModal() {
    this.modalService.createChatModel()
  }

  favoriteCity() {
    this.forumService.favoriteCities().subscribe((res: FavoriteCity[]) => {
      this.favCities = [...new Map(res.map(city => [city.id, city])).values()];
    })
  }

  addFavCity() {
    this.modalService.addFavCityModal();
  }
}
