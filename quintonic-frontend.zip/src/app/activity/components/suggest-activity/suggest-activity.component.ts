import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgbTypeahead, NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, merge, OperatorFunction } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';
import { ITheme } from 'src/app/shared/interfaces/common';
@Component({
	selector: 'app-suggest-activity',
	templateUrl: './suggest-activity.component.html',
	styleUrls: ['./suggest-activity.component.scss']
})
export class SuggestActivityComponent implements OnInit {
	@Input() themes: ITheme[] = [];
	model: any;
	@ViewChild('instance', { static: true }) instance!: NgbTypeahead;
	focus$ = new Subject<string>();
	click$ = new Subject<string>();
	search: any = (text$: Observable<string>) => {
		const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
		const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
		const inputFocus$ = this.focus$;

		return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
			map((term) =>
				(term === '' ? this.themes : this.themes.filter((v) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10),
			),
		);
	};

	constructor() { }

	ngOnInit(): void {
	}

	formatter = (x: { name: string }) => x.name;

}
