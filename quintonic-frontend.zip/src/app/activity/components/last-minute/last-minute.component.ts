import { Component, OnInit } from '@angular/core';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { ILastMinute } from '../../interface/interface';
import { FormControl, FormGroup } from '@angular/forms';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
@Component({
  selector: 'app-last-minute',
  templateUrl: './last-minute.component.html',
  styleUrls: ['./last-minute.component.scss'],
})
export class LastMinuteComponent implements OnInit {

  lastMinutes: ILastMinute[] = [];
  filterForm: FormGroup;

  constructor(
    private activityService: ActivityService,
    private utilService: UtilityService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1),
      per_page: new FormControl(5),
      last_minute: new FormControl(true),
      order_by: new FormControl('event_date'),
      period: new FormControl('upcoming')
    });
  }

  ngOnInit(): void {
    this.lastMinute();
  }

  lastMinute() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.activityService.lastMinute(query).subscribe((res) => {
      this.lastMinutes = res;
    });
  }
}
