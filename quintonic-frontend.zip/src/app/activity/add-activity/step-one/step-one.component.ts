import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { ValidationService } from 'src/app/shared/services/validations/validations.sevice';
import { Options } from 'ngx-google-places-autocomplete/objects/options/options';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { FavoriteCity, ITheme } from 'src/app/shared/interfaces/common';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-step-one',
  templateUrl: './step-one.component.html',
  styleUrls: ['./step-one.component.scss']
})
export class StepOneComponent implements OnInit {

  options: Options = new Options({
    types: ['(cities)'],
    componentRestrictions: { country: 'FR' }
  });
  endDate: boolean = false;
  cities: FavoriteCity[] = [];
  eventForm: FormGroup;
  eventFormSecond: FormGroup;

  isSubmitted: boolean = false;
  editAddressMode: boolean = false;
  viewMapSidebar: boolean = false;
  hours = Array.from({ length: 24 }, (_, i) => i);
  minutes = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
  fieldRequired = MESSAGE.COMMON.fieldRequired;
  locationComponents: any = {
    street_number: 'short_name',
    route: 'long_name',
    locality: 'long_name',
    administrative_area_level_1: 'short_name',
    postal_code: 'short_name',
    country: 'long_name'
  };
  date = new Date();
  minDate = {
    year: this.date.getFullYear(),
    month: this.date.getMonth() + 1,
    day: this.date.getDay()
  };

  @Output() saveToDraft: EventEmitter<any> = new EventEmitter();
  @Output() nextStep: EventEmitter<any> = new EventEmitter();

  constructor(
    private activityService: ActivityService,
    private fb: FormBuilder,
    private activeModal: NgbActiveModal,
    private modalService: ModalService,
    private validationService: ValidationService
  ) {

    this.date.setDate(new Date().getDay() + 1);
    this.minDate = {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate()
    };

    this.eventForm = this.fb.group({
      title: ['', [
        this.validationService.requiredValidator(),
        this.validationService.minlengthValidator('title', 5),
        this.validationService.maxlengthValidator('title', 60)
      ]],
      theme_id: ['', [this.validationService.requiredValidator()]],
      place: ['', [this.validationService.requiredValidator()]],
      address: ['', [this.validationService.requiredValidator()]],
      address2: [''],
      region: [''],
      city: ['', [this.validationService.requiredValidator()]],
      postcode: ['', [this.validationService.requiredValidator(), this.validationService.onlyNumber()]],
      state: ['France', [this.validationService.requiredValidator()]],
      country: ['', [this.validationService.requiredValidator()]],
      favorite_city_id: ['', [this.validationService.requiredValidator()]],
      starts_at: ['', [this.validationService.requiredValidator()]],
      starts_hours: ['', [this.validationService.requiredValidator]],
      starts_mintues: ['', [this.validationService.requiredValidator]],
      ends_at: ['', []],
      ends_hours: ['', []],
      ends_minutes: ['', []],
      gender_parity: ['', []], 
      max_participants: ['', [
        this.validationService.requiredValidator(), 
        this.validationService.onlyNumber(),
        this.validationService.minValidator('max particepants', 2),
        this.validationService.maxValidator('max particepants', 500)
      ]],
      privacy: ['open'],
      commercial: ['false'],
      publish: ['']
    });

    this.eventFormSecond = this.fb.group({
      suggested_picture_id: ['', [this.validationService.requiredValidator()]],
      publish: ['']
    })
  }

  selectedTheme(event: ITheme) {
    if (event) {
      this.eventForm.get('theme_id')?.setValue(event.id);
    } else {
      this.eventForm.get('theme_id')?.setValue(undefined);
    }
  }

  selectedCity(event: FavoriteCity) {
    if (event) {
      this.eventForm.get('favorite_city_id')?.setValue(event.id);
    } else {
      this.eventForm.get('favorite_city_id')?.setValue(undefined);
    }
  }

  ngOnInit(): void {
    this.favoriteCities();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.eventForm.controls;
  }

  display: any;
  center: google.maps.LatLngLiteral = { lat: 0, lng: 0 };
  zoom = 10;

  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.center = (event.latLng.toJSON());
  }
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.display = event.latLng.toJSON();
  }  

  favoriteCities() {
    this.activityService.favoriteCity().subscribe((res) => {
      this.cities = res;
    });
  }  

  openBecomeMemberModel() {
    this.activeModal.close()
    this.modalService.becomeAMemer()
  }

  doSaveToDraft() {
    this.saveToDraft.emit({data: this.eventForm.value});
  }

  doNextStep() {
    this.isSubmitted = true;
    if (this.eventForm.valid) {
      this.nextStep.emit({data: this.eventForm.value, nextStep: 2});
    } else {
      this.eventForm.markAllAsTouched();
    }
  }

  handleAddressChange(place: Address) {
    let address: any = {}
    place.address_components.forEach((addressComponent: any) => {
      for (let addressType of addressComponent.types) {
        if (this.locationComponents[addressType]) {
          if (addressType === 'street_number')
            address.streetNumber = addressComponent[this.locationComponents[addressType]];
          else if (addressType !== 'country')
            address[addressType] = addressComponent[this.locationComponents[addressType]];
          else {
            address[addressType] = addressComponent['long_name'];
          }
        }
      }
    });

    if (place.types[0] !== "street_address") {
      address.place = place.name;
    }
    if (address.streetNumber && address.route) {
      address.route = address.streetNumber + " " + address.route;
    }
    else if (place.vicinity) {
      address.route = place.vicinity;
    }
    else {
      address.route = place.name;
    }

    console.log(address);

    // this.populateEventWithAddress(address);
    // this.showAddressDetail();
    // this.setMapCoordinates(place.geometry.location);
    // this._updateAddress()

    const latLng: google.maps.LatLngLiteral = {
      lat: place.geometry.location.lat(),
      lng: place.geometry.location.lng()
    };
    this.center = latLng;
    this.editAddressMode = true;

    const finalAddress = {
      place: address.place,
      address: address.route,
      state: address.administrative_area_level_1,
      postcode: address.postal_code,
      city: address.locality,
      country: address.country
    };

    this.eventForm.patchValue(finalAddress);

    console.log(this.eventForm.value);
  }

  formatter = (x: { name: string }) => x.name;

  specifyAddress() {
    this.editAddressMode = true;
    this.viewMapSidebar = true;
  }

  editAddress() {
    this.editAddressMode = false;
    this.viewMapSidebar = false;
  }

  showEndDate() {
    this.endDate = this.endDate ? false : true;
    if(this.endDate){
      this.eventForm.get('ends_at')?.setValidators([Validators.required]);
      this.eventForm.get('ends_hours')?.setValidators([Validators.required]);
      this.eventForm.get('ends_minutes')?.setValidators([Validators.required]);
    } else {
      this.eventForm.get('ends_at')?.clearValidators();
      this.eventForm.get('ends_hours')?.clearValidators();
      this.eventForm.get('ends_minutes')?.clearValidators();
    }
    this.eventForm.get('ends_at')?.updateValueAndValidity();
    this.eventForm.get('ends_hours')?.updateValueAndValidity();
    this.eventForm.get('ends_minutes')?.updateValueAndValidity();
  }
}
