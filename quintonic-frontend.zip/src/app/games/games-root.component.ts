import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-games-root',
  templateUrl: './games-root.component.html',
  styleUrls: ['./games-root.component.scss']
})
export class GamesRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
