import { Component, OnInit } from '@angular/core';
import { TABS } from '../constants/tabs';
import { ITabs } from 'src/app/shared/interfaces/ui';
import { FormControl, FormGroup } from '@angular/forms';
import { MeetUpService } from 'src/app/shared/services/meet-up/meet-up.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { IMeetup } from 'src/app/shared/interfaces/meetup';

@Component({
  selector: 'app-you-match',
  templateUrl: './you-match.component.html',
  styleUrls: ['./you-match.component.scss'],
})
export class YouMatchComponent implements OnInit {
  tabs: ITabs[] = TABS;
  filterForm: FormGroup;
  matches: IMeetup[] = [];

  constructor(
    private meetUpService: MeetUpService,
    private utilService: UtilityService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1),
      per_page: new FormControl(15),
    });
  }

  ngOnInit(): void {
    this.tabs[0].selected = false;
    this.tabs[1].selected = false;
    this.tabs[2].selected = true;
    this.match();
  }

  match() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.meetUpService.matchtes(query).subscribe((res) => {
      this.matches = res;
      console.log('Matches:', res);
    });
  }
}
