import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeRootComponent } from './home-root.component';
import { HomeComponent } from './home/home.component';
import { RegisterStepOneComponent } from './register-step-one/register-step-one.component';
import { RegisterStepTwoComponent } from './register-step-two/register-step-two.component';
import { RegisterStepThreeComponent } from './register-step-three/register-step-three.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AidComponent } from './aid/aid.component';
import { EventFaqComponent } from './event-faq/event-faq.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { LegalNoticeComponent } from './legal-notice/legal-notice.component';
import { UserCharterComponent } from './user-charter/user-charter.component';
import { RegionalGroupsComponent } from './regional-groups/regional-groups.component';
import { QuintonicIntroComponent } from './quintonic-intro/quintonic-intro.component';
import { AuthGuard } from '../shared/guards/auth.guard';
import { PasswordResetComponent } from './password-reset/password-reset.component';
import { NotificationsComponent } from './notifications/notifications.component';

const routes: Routes = [
  {
    path: '',
    component: HomeRootComponent,
    children: [
      {
        path: '',
        component: HomeComponent,
      },
      {
        path: 'profile-completion/step-one',
        component: RegisterStepOneComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'profile-completion/step-two',
        component: RegisterStepTwoComponent,
      },
      {
        path: 'profile-completion/step-three',
        component: RegisterStepThreeComponent,
      },
      {
        path: 'contact-us',
        component: ContactUsComponent,
      },
      {
        path: 'aid',
        component: AidComponent,
      },
      {
        path: 'event-faq',
        component: EventFaqComponent,
      },
      {
        path: 'about-us',
        component: AboutUsComponent,
      },
      {
        path: 'conditions-generales',
        component: TermsAndConditionsComponent,
      },
      {
        path: 'mentions-legales',
        component: LegalNoticeComponent,
      },
      {
        path: 'charte-utilisateurs',
        component: UserCharterComponent,
      },
      {
        path: 'groupes',
        component: RegionalGroupsComponent,
      },
      {
        path: 'quintonic-intro',
        component: QuintonicIntroComponent,
      },
      {
        path: 'password-reset',
        component: PasswordResetComponent,
      }, {
        path: 'notifications',
        component: NotificationsComponent
      }
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomeRoutingModule {}
