import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { Router } from '@angular/router';
import { ModalService } from '../../services/modal/modal.service';
import { AuthService } from '../../services/auth/auth.service';
import { APP } from '../../constant/app.constant';
import { ValidationService } from '../../services/validations/validations.sevice';
import { MessageService } from '../../services/message/message.service';
import { StartupService } from '../../services/startup/startup.service';
import { FLASH_MESSAGE } from '../../constant/flash-message.constants';
import { UtilityService } from '../../services/utility/utility.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted: boolean = false;
  fieldRequired = MESSAGE.COMMON.fieldRequired;
  invalidEmail = MESSAGE.AUTH.invalidEmail;
  errorMessage: string = '';
  isLoading = false;
  constructor(
    public activeModal: NgbActiveModal,
    private fb: FormBuilder,
    private homeService: HomeService,
    private router: Router,
    private modalService: ModalService,
    private auth: AuthService,
    private validationService: ValidationService,
    private messageService: MessageService,
    private startupService: StartupService,
    private utilService: UtilityService
  ) {
    this.loginForm = this.fb.group({
      email: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.emailValidator,
          this.validationService.maxlengthValidator('email', 320),
        ],
      ],
      password: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.minlengthValidator('password', 8),
        ],
      ],
      remember_me: [false]
    });
  }

  ngOnInit(): void {
  }

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  loginSubmit() {
    if (!this.loginForm.valid) return;
    this.isSubmitted = true;
    this.homeService.login(this.loginForm.value).subscribe({
      next: (response) => {
        this.isSubmitted = false;
        if (response.body.data) {
          this.auth.setValue(
            APP.COOKIE.ACCESS_TOKEN,
            response.headers.get(APP.COOKIE.ACCESS_TOKEN)
          );
          this.auth.setValue(
            APP.COOKIE.CLIENT,
            response.headers.get(APP.COOKIE.CLIENT)
          );
          this.auth.setValue(
            APP.COOKIE.UID,
            response.headers.get(APP.COOKIE.UID)
          );
          this.activeModal.close();
          this.loginForm.reset();
          this.startupService.setUser(response.body.data);
          this.messageService.sendMessage({ type: APP.MESSAGE.LOGGED_IN });
          const message = FLASH_MESSAGE.LOGIN.replace('{username}', response.body.data.user_name);
          this.utilService.emitFlashMessage(message);
          if (!response.body.data.confirmed) {
            this.router.navigateByUrl('/groupes/activites');
            this.modalService.finalizeRegistration(response.body.data.email);
          } else if (!response.body.data.profile_completed_at) {
            this.router.navigateByUrl('/profile-completion/step-one');
          } else {
            this.startupService.validateToken()
              .then(res => {
                this.router.navigateByUrl('/groupes/activites');
              });
          }
        }
      },
      error: (error) => {
        this.isSubmitted = false;
        this.errorMessage = error.error.errors[0];
      },
    });
  }

  goToRegister() {
    this.activeModal.close();
    this.modalService.registerModal();
  }

  goToForgotPassword() {
    this.activeModal.close();
    this.modalService.forgotPasswordModal();
  }
}
