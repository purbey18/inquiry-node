import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-like',
  templateUrl: './no-like.component.html',
  styleUrls: ['./no-like.component.scss']
})
export class NoLikeComponent implements OnInit {
  @Input() title!:string;
  constructor() { }

  ngOnInit(): void {
  }

}
