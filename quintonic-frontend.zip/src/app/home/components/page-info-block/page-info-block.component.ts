import { Component, Input, OnInit } from '@angular/core';
import { IPageInfoBlock } from '../../interface/interface';

@Component({
  selector: 'app-page-info-block',
  templateUrl: './page-info-block.component.html',
  styleUrls: ['./page-info-block.component.scss']
})
export class PageInfoBlockComponent implements OnInit {
  @Input() data!: IPageInfoBlock;
  constructor() { }

  ngOnInit(): void {
  }

}
