import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Options } from '@angular-slider/ngx-slider';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss'],
})
export class AdvanceSearchComponent implements OnInit {
  disableEncounter: boolean = false;

  ageMinValue: number = 49;
  ageMaxValue: number = 81;
  distane: number = 457;

  maxAgeOptions: Options = {
    floor: 45,
    ceil: 100,
    hideLimitLabels: true,
  };

  maxDistanceOptions = {
    floor: 10,
    ceil: 1000,
    hideLimitLabels: true,
    translate: (value: number): string => {
      return `+${value} km`;
    },
  };

  advanceFilter = {
    meetup_distance: this.distane,
    meetup_enabled: true,
    meetup_gender: 'M',
    meetup_max_age: this.ageMaxValue,
    meetup_min_age: this.ageMinValue,
  };

  @Output() advanceFilterUpdated: EventEmitter<any> = new EventEmitter();
  constructor() {}

  ngOnInit(): void {}

  handleCheckboxChange() {
    this.disableEncounter = this.disableEncounter ? false : true;
  }

  handleCheckboxSelection(value: string) {
    this.advanceFilter.meetup_gender = value;
  }

  doAdvanceSearch() {
    this.advanceFilterUpdated.emit(this.advanceFilter);
  }

  onAgeChange(e: any) {
    this.advanceFilter.meetup_max_age = e.highValue;
    this.advanceFilter.meetup_min_age = e.value;
  }

  onDistanceChange(e: any) {
    this.advanceFilter.meetup_distance = e.value;
  }
}
