import { Component, OnInit } from '@angular/core';
import { Imeeting } from 'src/app/shared/interfaces/header';
import { HeaderService } from 'src/app/shared/services/header/header.service';
import { UserService } from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-meeting-moment',
  templateUrl: './meeting-moment.component.html',
  styleUrls: ['./meeting-moment.component.scss'],
})
export class MeetingMomentComponent implements OnInit {
  meetings: Imeeting[] = [];
  meetingMomentCount = 0;
  isLoading = true;
  constructor(
    private headerService: HeaderService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.meetingFetch();
    this.userService.meetCount().subscribe((res) => {
      this.meetingMomentCount = res;
    });
  }

  meetingMoment() {
    this.isLoading = true;
    return this.headerService.meeting_moment().subscribe((res) => {
      this.meetings = res;
      this.isLoading = false;
    });
  }

  meetingFetch() {
    return this.headerService.meeting_fetch().subscribe((res) => {});
  }
}
