export interface IBreadcrumb {
    label: string;
    url: string;
}
export interface IArticalDetails {
    id: number
    title: string
    body: string
    slug: string
    picture: Picture
    created_at: string
    published_at: string
    updated_at: string
    magazine_subcategory: MagazineSubcategory
}

export interface Picture {
    large: string
    small: string
}

export interface MagazineSubcategory {
    id: number
    name: string
    slug: string
    picture: Picture2
    parent: Parent
    type: string
    magazine_seo_block: string
}

export interface Picture2 {
    large: string
    small: string
}

export interface Parent {
    id: number
    name: string
    slug: string
    picture: Picture3
    parent: any
    type: string
    magazine_seo_block: string
}

export interface Picture3 {
    large: string
    small: string
}
