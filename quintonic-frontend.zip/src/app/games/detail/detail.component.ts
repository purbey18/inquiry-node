import { Component, OnInit, } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent implements OnInit {
  url!: SafeUrl;
  slug = '';
  constructor(
    private route: ActivatedRoute,
    private domSanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.slug = this.route.snapshot.params['slug'];
    this.url = this.domSanitizer.bypassSecurityTrustResourceUrl(`/assets/games/${this.slug}/index.html`);

  }
}
