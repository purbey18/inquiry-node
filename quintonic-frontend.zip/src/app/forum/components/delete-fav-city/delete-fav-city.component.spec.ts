import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteFavCityComponent } from './delete-fav-city.component';

describe('DeleteFavCityComponent', () => {
  let component: DeleteFavCityComponent;
  let fixture: ComponentFixture<DeleteFavCityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteFavCityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeleteFavCityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
