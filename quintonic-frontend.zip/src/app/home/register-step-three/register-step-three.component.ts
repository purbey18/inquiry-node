import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { UserService } from 'src/app/shared/services/user/user.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';

@Component({
  selector: 'app-register-step-three',
  templateUrl: './register-step-three.component.html',
  styleUrls: ['./register-step-three.component.scss']
})
export class RegisterStepThreeComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  isSubmitted = false;
  isSubmittedProfilePicture = false;
  constructor(
    private userService: UserService,
    private router: Router,
    private utilService: UtilityService
  ) { }

  ngOnInit(): void {
  }

  completeProfile() {
    this.isSubmitted = true;
    this.userService.updateProfile({ completeProfile: true })
      .subscribe({
        next: res => {
          this.isSubmitted = false;
          this.router.navigateByUrl('/groupes/activites');
        },
        error: error => {
          console.log(error);
        }
      });
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    console.log(event);
  }

  dropped(e: any) {
    for (const droppedFile of e) {
      const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
      fileEntry.file((file: File) => {
        this.imageChangedEvent = { target: { files: [file] } }
      });
    }
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }

  uploadAvatar() {
    if (this.croppedImage) {
      this.isSubmittedProfilePicture = true;

      const file = this.utilService.dataURIToBlob(this.croppedImage);
      const formData = new FormData();
      formData.append('avatar', file);
      this.userService.updateAvatar(formData)
        .subscribe(res => {
          this.isSubmittedProfilePicture = false;
          this.router.navigateByUrl('/groupes/activites');
        });
    } else {
      console.log('errorrrrr');
    }
  }

}
