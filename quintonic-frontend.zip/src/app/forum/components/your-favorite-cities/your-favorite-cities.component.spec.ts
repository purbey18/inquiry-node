import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YourFavoriteCitiesComponent } from './your-favorite-cities.component';

describe('YourFavoriteCitiesComponent', () => {
  let component: YourFavoriteCitiesComponent;
  let fixture: ComponentFixture<YourFavoriteCitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YourFavoriteCitiesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(YourFavoriteCitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
