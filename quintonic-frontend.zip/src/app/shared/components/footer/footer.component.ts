import { Component, OnInit } from '@angular/core';
import { IArtical } from 'src/app/activity/interface/interface';
import { ArticalService } from '../../services/artical/artical.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  articals: IArtical[] = [];
  constructor(private ArticalService: ArticalService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.ArticalService.list().subscribe((res) => {
      this.articals = res;
    });
  }
}
