import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ITag } from 'src/app/activity/interface/interface';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { UserService } from 'src/app/shared/services/user/user.service';
@Component({
  selector: 'app-register-step-one',
  templateUrl: './register-step-one.component.html',
  styleUrls: ['./register-step-one.component.scss']
})
export class RegisterStepOneComponent implements OnInit {
  ifSelectedHobby: boolean = false;
  isSubmitted = false;
  selectedHobbies: ITag[] = [];

  constructor(
    private homeService: HomeService,
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  getHobby(hobby: any) {
    this.selectedHobbies = hobby;
  }

  onSubmit() {
    this.ifSelectedHobby = this.selectedHobbies.length > 0 ? false : true;
    const hobby_list = this.selectedHobbies.map(h => h.name);
    if (hobby_list.length) {
      this.isSubmitted = true;
      this.userService.updateProfile({ hobby_list })
        .subscribe({
          next: res => {
            this.isSubmitted = false;
            this.router.navigateByUrl('/profile-completion/step-two');
          },
          error: error => { }
        });
    }
  }

}
