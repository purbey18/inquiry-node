import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-magazine-root',
  templateUrl: './magazine-root.component.html',
  styleUrls: ['./magazine-root.component.scss']
})
export class MagazineRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
