import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { ModalService } from '../../services/modal/modal.service';
import { environment } from 'src/environments/environment';
import { UserService } from '../../services/user/user.service';
import { MessageService } from '../../services/message/message.service';
import { APP } from '../../constant/app.constant';
import { AuthService } from '../../services/auth/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-modify-email',
  templateUrl: './modify-email.component.html',
  styleUrls: ['./modify-email.component.scss']
})
export class ModifyEmailComponent implements OnInit {
  @Input() email!: string

  isSubmitted: boolean = false;
  fieldRequired = MESSAGE.COMMON.fieldRequired;
  invalidEmail = MESSAGE.AUTH.invalidEmail;

  editEmailForm: FormGroup = new FormGroup({
    email: new FormControl(this.email, [Validators.required, Validators.email])
  });
  emailExistsErrorMessage = '';
  constructor(
    public activeModal: NgbActiveModal,
    private homeService: HomeService,
    private modalService: ModalService,
    private userService: UserService,
    private messageService: MessageService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    console.log('email:', this.email);
    this.editEmailForm.get('email')?.setValue(this.email);
  }

  get f(): { [key: string]: AbstractControl } {
    return this.editEmailForm.controls;
  }

  modifyEmail() {

    if (this.emailExistsErrorMessage) {
      return;
    }

    this.isSubmitted = true;
    if (!this.editEmailForm.valid) {
      return;
    };

    if (this.email === this.editEmailForm.value.email) {
      this.activeModal.close();
      this.modalService.modifyEmail(this.email);
      return;
    }

    const data = {
      config_name: "default",
      confirm_success_url: environment.confirm_success_url,
      new_email: this.editEmailForm.value.email,
      resend_confirmation_instructions: true
    }
    this.homeService.modifyEmail(data).subscribe(
      {
        next: res => {
          this.activeModal.close();
          this.modalService.finalizeRegistration(data.new_email);
        },
        error: err => {
          console.log(err);
          this.emailExistsErrorMessage = err.error.errors[0];
        }
      }
    )
  }

  checkEmail() {
    this.homeService.validateEmail(this.editEmailForm.value.email)
    .subscribe({
      next: res => {
        console.log(res);
        if (!res.isValid) {
          this.emailExistsErrorMessage = 'Cette adresse email est déjà utilisée';
        } else {
          this.emailExistsErrorMessage = '';
        }
      },
      error: err => {
        console.log(err);
      }
    })
  }

  signout() {
    this.userService.signout()
      .subscribe({
        next: res => {
          console.log(res);
          this.messageService.sendMessage({ type: APP.MESSAGE.SIGN_OUT });
          this.activeModal.close();
          this.authService.clearUserPreference();
          this.router.navigateByUrl('/groupes/activites');
        }
      })
  }

}
