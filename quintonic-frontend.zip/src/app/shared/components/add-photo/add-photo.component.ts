import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { UtilityService } from '../../services/utility/utility.service';
import { APP } from '../../constant/app.constant';
import { ModalService } from '../../services/modal/modal.service';
import { IPicture } from '../../interfaces/profile';
import { UserService } from '../../services/user/user.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-add-photo',
  templateUrl: './add-photo.component.html',
  styleUrls: ['./add-photo.component.scss']
})
export class AddPhotoComponent implements OnInit {
  @Input() crop: boolean = false
  @Input() albumPhoto!: IPicture
  @Output() selectedImage: EventEmitter<any> = new EventEmitter();

  imageChangedEvent: any = '';
  croppedImage: any = '';
  imagePreviewUrl: any = '';
  filename = '';

  constructor(
    private utilService: UtilityService,
    private modalService: ModalService,
    private userService: UserService,
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit(): void {
    if (this.albumPhoto) {
      this.imageChangedEvent = true
      this.imagePreviewUrl = this.albumPhoto.url.small
    }
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;

    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);

    this.filename = event.target.files[0].name;

    reader.onload = (_event) => {
      this.imagePreviewUrl = reader.result;
    }
  }

  dropped(e: any) {
    for (const droppedFile of e) {
      const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
      fileEntry.file((file: File) => {
        this.imageChangedEvent = { target: { files: [file] } }
      });
    }
  }

  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }

  selectImage() {
    if (this.albumPhoto) {
      this.selectedImage.emit({ type: APP.CONFIRMATION.OK, picture: this.albumPhoto });
    } else {
      const file = this.utilService.dataURIToBlob(this.imagePreviewUrl);
      this.selectedImage.emit({ type: APP.CONFIRMATION.OK, file, filename: this.filename });
    }
  }

  showAlbumPhotos() {
    this.modalService.albumPhotos()
  }

  uploadAvatar() {
    console.log('this.croppedImage:', this.croppedImage)
    if (this.croppedImage) {

      const file = this.utilService.dataURIToBlob(this.croppedImage);
      const formData = new FormData();

      formData.append('avatar', file);
      this.userService.updateAvatar(formData)
        .subscribe(res => {
          console.log('RES:', res)
        });
    } else {
      console.log('errorrrrr');
    }
  }

}
