import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { Editor } from 'ngx-editor';
import { ITag } from '../../interface/interface';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
@Component({
  selector: 'app-step-two',
  templateUrl: './step-two.component.html',
  styleUrls: ['./step-two.component.scss']
})
export class StepTwoComponent implements OnInit {

  editor!: Editor;
  html = '';
  hashTagList: any = []
  searchTerm: string = '';
  tagSuggestionList: ITag[] = [];
  @Output() saveToDraft: EventEmitter<any> = new EventEmitter();
  @Output() nextStep: EventEmitter<any> = new EventEmitter();
  constructor(
    private homeService: HomeService,
  ) { }

  ngOnInit(): void {
    this.editor = new Editor();
  }

  ngOnDestroy(): void {
    this.editor.destroy();
  }

  getValueFromEditor() {
    console.log(this.html);
  }

  searchTags() {
    this.homeService.searchTag(this.searchTerm).subscribe((response: any) => {
      this.tagSuggestionList = response
      console.log(this.tagSuggestionList)
    })
  }

  addHashTag(tag: any) {
    this.hashTagList.push(tag);
    this.searchTerm = '';
  }

  doSaveToDraft() {
    const ids = this.hashTagList.map((h: any) => h.id);
    console.log(ids);
    this.saveToDraft.emit({data: {description: this.html, tag_ids: ids}});
  }

  doNextStep() {
    const ids = this.hashTagList.map((h: any) => h.id);
    console.log(ids);
    if(this.html.length>=125){
    this.nextStep.emit({data: {description: this.html, tag_ids: ids}, nextStep: 3});
    }else{

    }
  }
  addCustomeTag(tagName: string){
    const model= {name: tagName};
      this.homeService.addCustomeTag(model).subscribe({
        next:res=>{
            this.hashTagList.push(res);
            this.searchTerm = "";
        },
        error: err => {
          console.log(err)
        }})
  }

}
