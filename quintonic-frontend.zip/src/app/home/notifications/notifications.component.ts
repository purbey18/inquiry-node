import { Component, OnInit } from '@angular/core';
import { IacceptRequestNotifications } from 'src/app/shared/interfaces/header';
import { HeaderService } from 'src/app/shared/services/header/header.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss'],
})
export class NotificationsComponent implements OnInit {
  notifications: IacceptRequestNotifications[] = [];
  constructor(private headerService: HeaderService) {}
  totalItems = 0;
  page = 1;
  perPage = 18;
  nextPage = 0;
  ngOnInit(): void {
    this.listNotification();
  }

  listNotification() {
    this.headerService.notification(this.page, this.perPage).subscribe((res) => {
      this.notifications = [...this.notifications, ...res.body];
      this.totalItems = res.headers.get('x-total');
      this.nextPage = res.headers.get('x-next-page');
    });
  }

  updatePagination(e: any) {
    this.page = e;
    this.listNotification();
  }
}
