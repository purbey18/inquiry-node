import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LatestForumTopicsComponent } from './latest-forum-topics.component';

describe('LatestForumTopicsComponent', () => {
  let component: LatestForumTopicsComponent;
  let fixture: ComponentFixture<LatestForumTopicsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LatestForumTopicsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LatestForumTopicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
