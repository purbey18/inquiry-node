import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared/shared.module';
import { InstantDatingRootComponent } from './instant-dating-root.component';
import { InstantDatingComponent } from './instant-dating/instant-dating.component';
import { InstantDatingRoutingModule } from './instant-dating-routing.module';
import { MeetComponent } from './meet/meet.component';
import { TheyChooseComponent } from './they-choose/they-choose.component';
import { YouMatchComponent } from './you-match/you-match.component';
import { AdvanceSearchComponent } from './components/advance-search/advance-search.component';
import { NoLikeComponent } from './components/no-like/no-like.component';
import { NoSuggestionComponent } from './components/no-suggestion/no-suggestion.component';

@NgModule({
  declarations: [
    InstantDatingRootComponent,
    InstantDatingComponent,
    MeetComponent,
    TheyChooseComponent,
    YouMatchComponent,
    AdvanceSearchComponent,
    NoLikeComponent,
    NoSuggestionComponent
  ],
  imports: [
    InstantDatingRoutingModule,
    SharedModule
  ]
})
export class InstantDatingModule { }
