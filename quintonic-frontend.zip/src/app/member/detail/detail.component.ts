import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { IFavorite, IMember } from '../interface/interface';
import { ITabs } from 'src/app/shared/interfaces/ui';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { APP } from 'src/app/shared/constant/app.constant';
import { HeaderService } from 'src/app/shared/services/header/header.service';
import { IUser } from 'src/app/shared/interfaces/common';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent implements OnInit {
  category: string = 'news'
  RELATIONSHIP_STATUS = APP.RELATIONSHIP;
  user!: IUser;
  type: any;
  friendList: IUser[] = [];
  books: IFavorite[] = [];
  shows: IFavorite[] = [];
  movies: IFavorite[] = [];
  tabs: ITabs[] = [
    {
      title: 'News',
      selected: true,
      route: '',
      key: 'journal'
    },
    {
      title: 'Exist',
      selected: false,
      route: '',
      key: 'events'
    },
    {
      title: 'Pictures',
      selected: false,
      route: '',
      key: 'pictures'
    }
  ];

  constructor(
    private memberService: MemberService,
    private route: ActivatedRoute,
    private router: Router,
    private modalService: ModalService,
    private headerService: HeaderService
  ) { }

  ngOnInit(): void {
    const name = this.route.snapshot.paramMap.get('name');
    this.type = this.route.snapshot.paramMap.get('type');

    console.log(this.type);

    this.tabs[0].route = `/users/${name}/journal`;
    this.tabs[1].route =  `/users/${name}/events`;
    this.tabs[2].route =  `/users/${name}/pictures`;

    this.tabChanged({type: this.type});
    this.userDetail();
  }

  userDetail() {
    this.memberService
      .detail(this.route.snapshot.paramMap.get('name') || '')
      .subscribe((res) => {
        this.user = res;
        this.friends(this.user.id)
        this.favorite_books(this.user.id)
        this.favorite_shows(this.user.id)
        this.favorite_movies(this.user.id)
        console.log('user:', this.user);
      });
  }

  tabChanged(e: any) {
    this.tabs.forEach(t => {
      if (t.key === e.type) {
        t.selected = true;
      } else {
        t.selected = false
      }
    });
  }

  tabClicked(e: ITabs) {
    this.type = e.key;
  }

  friends(id: number) {
    this.memberService
      .friends(id)
      .subscribe((res) => {
        this.friendList = res;
        console.log('friends:', res)
      })
  }

  favorite_shows(id: number) {
    this.memberService.favorite_shows(id).subscribe((res) => {
      this.shows = res;
      console.log('shows:', res)
    })
  }

  favorite_books(id: number) {
    this.memberService.favorite_books(id).subscribe((res) => {
      this.books = res;
      console.log('books:', res)
    })
  }

  favorite_movies(id: number) {
    this.memberService.favorite_movies(id).subscribe((res) => {
      this.movies = res;
      console.log('movies:', res)
    })
  }
  openRequestDialog(){
    this.modalService.sendRequest(this.user);
  }
  acceptFriendRequest(){
    this.headerService.requestAccept(this.user.id).subscribe({
      next: res=>{
        this.user.relationship = res;
      },
      error: error=> {
        console.log(error);
        
      }
    })
  }
  rejectFriendRequest(){
    this.headerService.requestReject(this.user.id).subscribe({
      next: res=>{
        this.user.relationship = res;
      },
      error: error=> {
        console.log(error);
        
      }
    })
  }
  reportUser(){
    console.log("test");
    
    this.modalService.abusiveContent('DO YOU FIND THIS CONTENT ABUSIVE?','Our moderators will check its content','send','cancel','users/'+this.user.id+'/report');
  }
}
