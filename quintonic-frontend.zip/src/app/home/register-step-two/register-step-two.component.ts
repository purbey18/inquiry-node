import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from 'ngx-editor';
import { UserService } from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-register-step-two',
  templateUrl: './register-step-two.component.html',
  styleUrls: ['./register-step-two.component.scss']
})
export class RegisterStepTwoComponent implements OnInit {
  profileUpdate: FormGroup;
  isSubmitted = false;
  isFormInvalid: boolean = false;
  isEditUsername = false;
  constructor(
    private userService: UserService,
    private router: Router
  ) {
    this.profileUpdate = new FormGroup({
      user_name: new FormControl('', [Validators.required()]),
      biography: new FormControl('', [Validators.required()])
    });
  }

  ngOnInit(): void {
    this.userService.profile()
    .subscribe({
      next: res => {
        console.log(res);
        this.profileUpdate.get('user_name')?.setValue(res.user_name);
        this.profileUpdate.get('biography')?.setValue(res.biography);
      },
      error: error => {
        console.log(error);
      }
    })
  }

  onSubmit() {
    console.log('submit');
    this.isFormInvalid = !this.profileUpdate.valid;
    this.userService.updateProfile({...this.profileUpdate.value})
    .subscribe({
      next: res => {
        console.log(res);
        this.isSubmitted = false;
        this.router.navigateByUrl('/profile-completion/step-three');
      },
      error: error => {}
    })
  }

}
