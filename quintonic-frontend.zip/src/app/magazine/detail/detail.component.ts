import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ArticalService } from 'src/app/shared/services/artical/artical.service';
import { IArticalDetails } from '../interface/interface';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
import { IUser } from 'src/app/shared/interfaces/common';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  article!: IArticalDetails;
  relatedArticle: any = []
  user!: IUser;
  commentText = ''

  constructor(
    private route: ActivatedRoute,
    private articalService: ArticalService,
    private startupService: StartupService
  ) { }

  ngOnInit(): void {
    this.getArticleDetails()
    this.user = this.startupService.getUser();
    console.log('this.user:', this.user)
  }

  getArticleDetails() {
    this.route.paramMap.subscribe(params => {
      const slug = params.get('slug');
      this.articalService.articleDetails(slug).subscribe((res) => {
        this.article = res
        this.getRelatedArticle(res.id)
      })
    });
  }

  getRelatedArticle(id: number) {
    this.articalService.related_article(id).subscribe((res) => {
      this.relatedArticle = res
    })
  }

}
