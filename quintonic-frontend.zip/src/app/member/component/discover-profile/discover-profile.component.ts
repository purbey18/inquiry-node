import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';

@Component({
  selector: 'app-discover-profile',
  templateUrl: './discover-profile.component.html',
  styleUrls: ['./discover-profile.component.scss']
})
export class DiscoverProfileComponent implements OnInit {

  constructor(
    public authService: AuthService,
    private modalService: ModalService
  ) { }

  ngOnInit(): void {
    console.log(this.authService.checkLoggedIn());
  
  }

  openLoginModal() {
    this.modalService.loginModal()
      .then(result => {
        console.log('Modal result:', result);
      })
      .catch(error => {
        console.log('Modal error:', error);
      });
  }


  openRegisterModal() {
    this.modalService.registerModal();
  }

}
