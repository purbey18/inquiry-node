import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, debounceTime, distinctUntilChanged, filter, map, merge, switchMap, tap } from 'rxjs';
import { ITheme } from 'src/app/shared/interfaces/common';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';

@Component({
	selector: 'app-theme-auto-complete',
	templateUrl: './theme-auto-complete.component.html',
	styleUrls: ['./theme-auto-complete.component.scss']
})
export class ThemeAutoCompleteComponent implements OnInit {
	themes: ITheme[] = [];
	model!: ITheme;
	@ViewChild('instance', { static: true }) instance!: NgbTypeahead;
	focus$ = new Subject<string>();
	click$ = new Subject<string>();
	search: any = (text$: Observable<string>) => {
		const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
		const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
		const inputFocus$ = this.focus$;

		return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
			tap(() => this.model = null as any),
			map((term) =>
				(term === '' ? this.themes : this.themes.filter((v) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10),
			),
		);
	};	
	@Output() selectedTheme: EventEmitter<ITheme> = new EventEmitter();
	form;
	constructor(
		private activityService: ActivityService,
		private fb: FormBuilder
	) {
		this.form = fb.group({
			obj: ['', null]
		});
	}

	ngOnInit(): void {
		this.theme();
	}

	theme() {
		this.activityService.theme()
			.subscribe(res => {
				this.themes = res;
			});
	}

	formatter = (x: { name: string }) => x.name;

	selectedItem(e: any) {
		this.model = e.item;
		this.selectedTheme.emit(e.item);
		this.form.get('obj')?.setValue(e.item);
	}

	blurObj() {
		if(!this.model) {
			this.selectedTheme.emit(undefined);
			this.form.get('obj')?.setValue('');
		}
	}

}
