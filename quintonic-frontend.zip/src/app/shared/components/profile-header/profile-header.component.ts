import { Component, Input, OnInit } from '@angular/core';
import { IUser } from 'src/app/shared/interfaces/common';
import { StartupService } from 'src/app/shared/services/startup/startup.service';

@Component({
  selector: 'app-profile-header',
  templateUrl: './profile-header.component.html',
  styleUrls: ['./profile-header.component.scss'],
})
export class ProfileHeaderComponent implements OnInit {
  @Input() showProfileButton = true;
  profile!: IUser;
  constructor(private startupService: StartupService) {}

  ngOnInit(): void {
    this.profile = this.startupService.getUser();
  }
}
