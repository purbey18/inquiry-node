import { IActivity, IArtical } from "src/app/activity/interface/interface";
import { IMember } from "src/app/member/interface/interface";
import { IForumDiscussion } from "src/app/shared/interfaces/common";

export interface ISearchData {
  total: number;
  users_count: number;
  magazine_articles_count: number;
  forum_discussions_count: number;
  upcoming_events: any[];
  upcoming_events_count: number;
  past_events: IActivity[];
  past_events_count: number;
  users: IMember[];
  magazine_articles: IArtical[];
  forum_discussions: IForumDiscussion[];
}

export interface CoverPicture {
  thumb: string;
  small: string;
  large: string;
}

export interface Theme {
  id: number;
  name: string;
  slug: string;
  picture: Picture;
  events_seo_top_block: any;
  events_seo_bottom_block: any;
  meta_title?: any;
  meta_desc?: any;
}

export interface Picture {
  url: string;
}

export interface Picture2 {
  large: string;
  small: string;
}

export interface Avatar {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}

export interface Hobby {
  id: number;
  name: string;
  theme_id: number;
}
export interface Picture3 {
  large: string;
  small: string;
}

export interface MagazineSubcategory {
  id: number;
  name: string;
  slug: string;
  picture: Picture4;
  parent: Parent;
  type: string;
  magazine_seo_block: any;
}

export interface Picture4 {
  large: any;
  small: any;
}

export interface Parent {
  id: number;
  name: string;
  slug: string;
  picture: Picture5;
  parent: any;
  type: string;
  magazine_seo_block: any;
}

export interface Picture5 {
  large: string;
  small: string;
}


export interface Avatar2 {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}

export interface Hobby2 {
  id: number;
  name: string;
  theme_id: number;
}