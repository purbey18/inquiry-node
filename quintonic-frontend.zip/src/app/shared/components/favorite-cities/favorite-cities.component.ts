import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, debounceTime, distinctUntilChanged, filter, map, merge, tap } from 'rxjs';
import { ActivityService } from '../../services/activity/activity.service';
import { FavoriteCity } from '../../interfaces/common';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-favorite-cities',
  templateUrl: './favorite-cities.component.html',
  styleUrls: ['./favorite-cities.component.scss'],
})
export class FavoriteCitiesComponent implements OnInit {
  form;
  @ViewChild('instance', { static: true }) instance!: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();
  model!: FavoriteCity;
  search: any = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(
      debounceTime(200),
      distinctUntilChanged()
    );
    const clicksWithClosedPopup$ = this.click$.pipe(
      filter(() => !this.instance.isPopupOpen())
    );
    const inputFocus$ = this.focus$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      tap(() => this.model = null as any),
      map((term) =>
        (term === ''
          ? this.favoriteCity
          : this.favoriteCity.filter(
            (v) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1
          )
        ).slice(0, 10)
      )
    );
  };
  favoriteCity: FavoriteCity[] = [];
  @Output() selectedItem = new EventEmitter<FavoriteCity>();
  constructor(
    private activityService: ActivityService,
    private fb: FormBuilder
  ) {
    this.form = fb.group({
      obj: ['', null]
    });
  }

  ngOnInit(): void {
    this.activityService.favoriteCity().subscribe((res) => {
      this.favoriteCity = res;
    });
  }

  formatter = (x: { name: string }) => x.name;

  itemChoose(item: any) {
    this.selectedItem.emit(item);
  }

  selectedCity(e: any) {
    this.model = e.item;
    this.selectedItem.emit(e.item);
    this.form.get('obj')?.setValue(e.item);
  }

  blurObj() {
    if (!this.model) {
      this.selectedItem.emit(undefined);
      this.form.get('obj')?.setValue('');
    }
  }
}
