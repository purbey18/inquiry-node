import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { HOME } from '../constants/home-constant';
import { MESSAGE } from 'src/app/shared/constant/message.constants'
  ;
import { AuthService } from 'src/app/shared/services/auth/auth.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']

})
export class HomeComponent implements OnInit {

  cityName: any
  years = Array.from({ length: 56 }, (_, i) => 1978 - i);
  months = Array.from({ length: 12 }, (_, i) => ({ name: new Date(2022, i).toLocaleString('default', { month: 'long' }), number: i + 1 }));
  dates = Array.from({ length: 31 }, (_, i) => i + 1);

  isSubmitted: boolean = false
  benifits: any[] = HOME.BENEFITS;
  engagements: any[] = HOME.ENGAGEMENTS;
  pageInfoBlock = HOME.PAGE_INFO_BLOCK;

  fieldRequired = MESSAGE.COMMON.fieldRequired;
  invalidEmail = MESSAGE.AUTH.invalidEmail;
  passwordMinlength = MESSAGE.AUTH.passwordMinLength
  nameMinLength = MESSAGE.AUTH.nameMinLength

  isLoggedIn = false;

  constructor(
    private modalService: ModalService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.isLoggedIn = this.authService.checkLoggedIn();
  }

  openLoginModal() {
    this.modalService.loginModal()
      .then(result => {
        console.log('Modal result:', result);
      })
      .catch(error => {
        console.log('Modal error:', error);
      });
  }
  
}
