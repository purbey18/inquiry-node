import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-suggestion',
  templateUrl: './no-suggestion.component.html',
  styleUrls: ['./no-suggestion.component.scss']
})
export class NoSuggestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
