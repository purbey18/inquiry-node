import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forum-root',
  templateUrl: './forum-root.component.html',
  styleUrls: ['./forum-root.component.scss']
})
export class ForumRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
