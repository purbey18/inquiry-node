import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quintotv-root',
  templateUrl: './quintotv-root.component.html',
  styleUrls: ['./quintotv-root.component.scss']
})
export class QuintotvRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
