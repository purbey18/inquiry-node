import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../services/modal/modal.service';
import { AuthService } from '../../services/auth/auth.service';
import { UserService } from '../../services/user/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IUser } from '../../interfaces/common';
import { StartupService } from '../../services/startup/startup.service';
import { MessageService } from '../../services/message/message.service';
import { APP } from '../../constant/app.constant';
import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  isLoggedIn: boolean = false;
  user!: IUser;
  query = '';
  errorMessage = '';
  messageCount = 0;
  showMegaMenu: boolean = false;

  constructor(
    private modalService: ModalService,
    private authService: AuthService,
    private userSerivce: UserService,
    private router: Router,
    private startupService: StartupService,
    private messageService: MessageService,
    private route: ActivatedRoute
  ) {
    this.messageService.getMessage().subscribe((res) => {
      if (res.type === APP.MESSAGE.LOGGED_IN) {
        this.isLoggedIn = this.authService.checkLoggedIn();
        this.user = this.startupService.getUser();
      } else if (res.type === APP.MESSAGE.SIGN_OUT) {
        this.isLoggedIn = false;
        this.user = null as any;
      } else if (res.type === APP.MESSAGE.FLASH_MESSAGE) {
        this.errorMessage = res.data.message;
      }
    });

    this.isLoggedIn = this.authService.checkLoggedIn();
  }

  ngOnInit(): void {

    this.route.queryParams.subscribe((params) => {
      this.query = params['query'];
    });

    if (this.isLoggedIn) {
      this.user = this.startupService.getUser();
      this.userSerivce.chatCount().subscribe((res) => {
        this.messageCount = res;
      });
    }
  }

  openLoginModal() {
    this.modalService.loginModal();
  }

  openRegisterModal() {
    this.modalService.registerModal();
  }

  signout() {
    this.userSerivce.signout().subscribe({
      next: async (res) => {
        this.isLoggedIn = false;
        this.user = null as any;
        this.authService.clearUserPreference();        
      },
    });
  }

  search() {
    this.router.navigate(['/search'], { queryParams: { query: this.query } });
  }

  over(drop:NgbDropdown) {
    drop.open();    
  }
  out(drop:NgbDropdown) {
    drop.close();
  }
}
