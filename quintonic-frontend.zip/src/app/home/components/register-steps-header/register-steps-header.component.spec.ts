import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterStepsHeaderComponent } from './register-steps-header.component';

describe('RegisterStepsHeaderComponent', () => {
  let component: RegisterStepsHeaderComponent;
  let fixture: ComponentFixture<RegisterStepsHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterStepsHeaderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterStepsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
