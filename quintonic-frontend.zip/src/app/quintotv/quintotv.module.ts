import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared/shared.module';
import { QuintotvRootComponent } from './quintotv-root.component';
import { QuintotvComponent } from './quintotv/quintotv.component';
import { QuintotvRoutingModule } from './quintotv-routing.module';

@NgModule({
  declarations: [
    QuintotvRootComponent,
    QuintotvComponent
  ],
  imports: [
    QuintotvRoutingModule,
    SharedModule
  ]
})
export class QuintotvModule { }
