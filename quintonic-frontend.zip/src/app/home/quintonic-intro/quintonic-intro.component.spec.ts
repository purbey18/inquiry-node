import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuintonicIntroComponent } from './quintonic-intro.component';

describe('QuintonicIntroComponent', () => {
  let component: QuintonicIntroComponent;
  let fixture: ComponentFixture<QuintonicIntroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuintonicIntroComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuintonicIntroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
