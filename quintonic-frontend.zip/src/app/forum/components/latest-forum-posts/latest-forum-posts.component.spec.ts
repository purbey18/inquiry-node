import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LatestForumPostsComponent } from './latest-forum-posts.component';

describe('LatestForumPostsComponent', () => {
  let component: LatestForumPostsComponent;
  let fixture: ComponentFixture<LatestForumPostsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LatestForumPostsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LatestForumPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
