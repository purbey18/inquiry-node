import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoSuggestionComponent } from './no-suggestion.component';

describe('NoSuggestionComponent', () => {
  let component: NoSuggestionComponent;
  let fixture: ComponentFixture<NoSuggestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoSuggestionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NoSuggestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
