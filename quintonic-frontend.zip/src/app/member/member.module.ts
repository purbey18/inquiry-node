import { NgModule } from '@angular/core';
import { MemberRootComponent } from './member-root.component';
import { MemberRoutingModule } from './member-routing.module';
import { SharedModule } from '../shared/shared/shared.module';
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';
import { AdvanceSearchComponent } from './component/advance-search/advance-search.component';
import { NewsComponent } from './component/news/news.component';
import { ExistsComponent } from './component/exists/exists.component';
import { PicturesComponent } from './component/pictures/pictures.component';
import { DiscoverProfileComponent } from './component/discover-profile/discover-profile.component';
import { SendRequestComponent } from './component/send-request/send-request.component';
import { AddFriendComponent } from './component/add-friend/add-friend.component';
@NgModule({
  declarations: [
    MemberRootComponent,
    ListComponent,
    DetailComponent,
    AdvanceSearchComponent,
    NewsComponent,
    ExistsComponent,
    PicturesComponent,
    DiscoverProfileComponent,
    SendRequestComponent,
    AddFriendComponent
  ],
  imports: [
    MemberRoutingModule,
    SharedModule
  ]
})
export class MemberModule { }
