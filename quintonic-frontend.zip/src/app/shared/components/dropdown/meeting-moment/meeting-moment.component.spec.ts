import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetingMomentComponent } from './meeting-moment.component';

describe('MeetingMomentComponent', () => {
  let component: MeetingMomentComponent;
  let fixture: ComponentFixture<MeetingMomentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MeetingMomentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MeetingMomentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
