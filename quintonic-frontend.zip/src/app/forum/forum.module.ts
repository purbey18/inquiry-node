import { NgModule } from '@angular/core';
import { ForumRootComponent } from './forum-root.component';
import { ForumComponent } from './forum/forum.component';
import { SharedModule } from '../shared/shared/shared.module';
import { ForumRoutingModule } from './forum-routing.module';
import { AddFavCityComponent } from './components/add-fav-city/add-fav-city.component';
import { LatestForumPostsComponent } from './components/latest-forum-posts/latest-forum-posts.component';
import { LatestForumTopicsComponent } from './components/latest-forum-topics/latest-forum-topics.component';
import { DiscussionComponent } from './discussion/discussion.component';
import { DeleteFavCityComponent } from './components/delete-fav-city/delete-fav-city.component';
import { DetailsComponent } from './details/details.component';
import { DirectivesModule } from '../shared/directive/directives.module';


@NgModule({
  declarations: [
    ForumRootComponent,
    ForumComponent,
    AddFavCityComponent,
    LatestForumPostsComponent,
    LatestForumTopicsComponent,
    DiscussionComponent,
    DeleteFavCityComponent,
    DetailsComponent
  ],
  imports: [
    ForumRoutingModule,
    SharedModule,
    DirectivesModule
  ]
})
export class ForumModule { }


