import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
import { UserService } from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-register-steps-header',
  templateUrl: './register-steps-header.component.html',
  styleUrls: ['./register-steps-header.component.scss']
})
export class RegisterStepsHeaderComponent implements OnInit {

  @Input() activeStep: any

  constructor(
    private userSerivce: UserService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  signout() {
    this.userSerivce.signout().subscribe({
      next: async (res) => {
        this.authService.clearUserPreference();
      },
    });
  }

}
