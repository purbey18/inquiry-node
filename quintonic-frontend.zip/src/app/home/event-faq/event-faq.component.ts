import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-faq',
  templateUrl: './event-faq.component.html',
  styleUrls: ['./event-faq.component.scss']
})
export class EventFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
