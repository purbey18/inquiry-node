import { Component, OnInit } from "@angular/core";
import { IArtical } from "src/app/activity/interface/interface";
import { ArticalService } from "../../services/artical/artical.service";

@Component({
  selector: "app-artical",
  templateUrl: "./artical.component.html",
  styleUrls: ["./artical.component.scss"],
})
export class ArticalComponent implements OnInit {
  articals: IArtical[] = [];
  constructor(private articalService: ArticalService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.articalService.list().subscribe((res) => {
      this.articals = res;
    });
  }
}
