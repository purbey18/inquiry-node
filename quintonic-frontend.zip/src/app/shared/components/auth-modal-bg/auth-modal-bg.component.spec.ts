import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthModalBgComponent } from './auth-modal-bg.component';

describe('AuthModalBgComponent', () => {
  let component: AuthModalBgComponent;
  let fixture: ComponentFixture<AuthModalBgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuthModalBgComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AuthModalBgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
