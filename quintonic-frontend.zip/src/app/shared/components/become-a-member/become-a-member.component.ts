import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-become-a-member',
  templateUrl: './become-a-member.component.html',
  styleUrls: ['./become-a-member.component.scss']
})
export class BecomeAMemberComponent implements OnInit {

  constructor(
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit(): void {
  }

  closeModel() {
    this.activeModal.close()
  }

}
