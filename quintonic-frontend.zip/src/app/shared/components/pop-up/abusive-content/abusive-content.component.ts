import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MemberService } from 'src/app/shared/services/member/member.service';


@Component({
  selector: 'app-abusive-content',
  templateUrl: './abusive-content.component.html',
  styleUrls: ['./abusive-content.component.scss'],
})
export class AbusiveContentComponent implements OnInit {
  @Input()title: string = 'DO YOU FIND THIS CONTENT ABUSIVE?';
  @Input()message: string = 'Our moderators will check its content';
  @Input()positiveButtonText = 'Send';
  @Input()negativeButtonText = 'Cancel';
  @Input()url = '';
  reportMessage: string = '';
  abusiveContent: FormGroup;
  constructor(
    public activeModal: NgbActiveModal,
    private memnerService: MemberService
  ) {
    this.abusiveContent = new FormGroup({
      title: new FormControl('', []),
    });
  }

  ngOnInit(): void {
      if(!this.title){
        this.title = 'DO YOU FIND THIS CONTENT ABUSIVE?';
        this.message = 'Our moderators will check its content';
        this.positiveButtonText = 'Send';
        this.negativeButtonText = 'Cancel';
      }
   }
   report(){
    console.log("test");
    
    const modal ={
      report_reason: this.reportMessage
    }
    this.memnerService.reportMember(this.url,modal).subscribe({
      next: res=>{
        console.log(res);
        this.activeModal.dismiss();
        
      },  
      error: error=>{
        console.log(error);
        
      }
    })
   }

}
