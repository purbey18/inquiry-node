export const MEMBER = {
    SORT_BY: [
        {
            name: 'users.list.orderBy.labels.proximity',
            value: 'proximity'
        },
        {
            name: 'users.list.orderBy.labels.recency',
            value: 'recency'
        },
        {
            name: 'users.list.orderBy.labels.lastConnection',
            value: 'last_connection'
        },
        {
            name: 'users.list.orderBy.labels.commonHobbies',
            value: 'common_hobbies'
        },
        {
            name: 'users.list.orderBy.labels.activity',
            value: 'activity'
        },
    ]
}