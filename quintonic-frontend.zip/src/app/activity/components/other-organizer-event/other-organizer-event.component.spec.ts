import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherOrganizerEventComponent } from './other-organizer-event.component';

describe('OtherOrganizerEventComponent', () => {
  let component: OtherOrganizerEventComponent;
  let fixture: ComponentFixture<OtherOrganizerEventComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherOrganizerEventComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OtherOrganizerEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
