import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PageInfoBlockComponent } from './page-info-block.component';

describe('PageInfoBlockComponent', () => {
  let component: PageInfoBlockComponent;
  let fixture: ComponentFixture<PageInfoBlockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PageInfoBlockComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PageInfoBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
