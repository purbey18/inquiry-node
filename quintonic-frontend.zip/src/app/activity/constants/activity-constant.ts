export const ACTIVITY = {
    RADIUS: [
      {
        name: 'A moins de 30km',
        value: '30',
      },
      {
        name: 'A moins de 60km',
        value: '60',
      },
      {
        name: 'A moins de 100km',
        value: '100',
      },
      {
        name: 'A moins de 200km',
        value: '200',
      },
      {
        name: 'A moins de 300km',
        value: '300',
      },
      {
        name: 'A moins de 1000km',
        value: '1000',
      },
    ],
    DATE: [
      {
        value: '',
        name: 'events.list.filters.period.label',
      },
      {
        value: 'next_week',
        name: 'events.list.filters.period.nextWeek',
      },
      {
        value: 'upcoming',
        name: 'events.list.filters.period.upcoming',
      },
      {
        value: 'last_minute',
        name: 'events.list.filters.period.lastMinute',
      },
      {
        value: 'this_week',
        name: 'events.list.filters.period.thisWeek',
      },
      {
        value: 'past',
        name: 'events.list.filters.period.past',
      },
    ],
    SORT_BY: [
      {
        value: 'event_date_desc',
        name: 'Date of activity',
      },
      {
        value: 'publication_date',
        name: 'Activity creation date',
      },
    ],
    GENDER: [
      {
        value: '',
        name: 'Tous',
      },
      {
        value: 'M',
        name: 'Hommes',
      },
      {
        value: 'F',
        name: 'Femmes',
      },
    ],
  };
  