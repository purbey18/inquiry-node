import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instant-dating',
  templateUrl: './instant-dating.component.html',
  styleUrls: ['./instant-dating.component.scss']
})
export class InstantDatingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
