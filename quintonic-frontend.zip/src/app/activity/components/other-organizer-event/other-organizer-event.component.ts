import { Component, Input, OnInit } from '@angular/core';
import { IActivity } from '../../interface/interface'; ''
import { IOrganizer } from 'src/app/shared/interfaces/common';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { FormControl, FormGroup } from '@angular/forms';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';

@Component({
  selector: 'app-other-organizer-event',
  templateUrl: './other-organizer-event.component.html',
  styleUrls: ['./other-organizer-event.component.scss']
})
export class OtherOrganizerEventComponent implements OnInit {
  @Input() user!: IOrganizer;
  @Input() eventId!: number

  events: IActivity[] = []
  filterForm!: FormGroup;
  totalItems = 0

  constructor(
    private activityService: ActivityService,
    private utilService: UtilityService
  ) { }

  ngOnInit(): void {
    this.filterForm = new FormGroup({
      'exclude[]': new FormControl(this.eventId),
      order_by: new FormControl('event_date'),
      organizer_id: new FormControl(this.user.id),
      page: new FormControl(1),
      per_page: new FormControl(5),
      period: new FormControl('upcoming')
    });
    this.organizerOtherevents()
  }

  organizerOtherevents() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.activityService.otherUserEvents(query).subscribe((res) => {
      this.totalItems = res.headers.get('x-total');
      this.events = res.body
    })
  }
}
