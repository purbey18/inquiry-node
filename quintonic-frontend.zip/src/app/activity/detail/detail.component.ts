import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import {
  IActivity,
  IComment,
  IEventStatus,
  IParticipant,
} from '../interface/interface';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { TranslateService } from '@ngx-translate/core';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
import { ProfileService } from 'src/app/shared/services/profile/profile.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { IPicture } from 'src/app/member/interface/interface';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { IOrganizer, ITheme, IUser } from 'src/app/shared/interfaces/common';
import { MessageService } from 'src/app/shared/services/message/message.service';
import { APP } from 'src/app/shared/constant/app.constant';
import { ITabs } from 'src/app/shared/interfaces/ui';

const TABS = {
  PARTICIPENT: 'participent',
  INVITES: 'invites',
};
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent implements OnInit {
  activity!: IActivity;
  participants: IParticipant[] = [];
  waitingParticipants: IParticipant[] = [];
  invitedParticipants: IParticipant[] = [];
  comments: IComment[] = [];
  userStatus!: IEventStatus;
  display: any;
  center: google.maps.LatLngLiteral = { lat: 0, lng: 0 };
  organizer: boolean = false;
  organizerDetails!: IOrganizer;
  zoom = 10;
  commentText = '';
  pictures: IPicture[] = [];
  filterForm: FormGroup;
  // participationForm: FormGroup;
  totalItems = 0;
  eventId!: number;
  user!: IUser;
  nextPage = 0;
  type: any = 'participent';
  theme!: ITheme;

  tabs: ITabs[] = [
    {
      title: 'ILS PARTICIPENT',
      selected: true,
      route: '',
      key: TABS.PARTICIPENT,
    },
    {
      title: 'INVITÉS',
      selected: false,
      route: '',
      key: TABS.INVITES,
    },
  ];

  showInvites = 6;

  moveMap(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.center = event.latLng.toJSON();
  }
  move(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) this.display = event.latLng.toJSON();
  }
  constructor(
    private route: ActivatedRoute,
    private activityService: ActivityService,
    private startupService: StartupService,
    private modalService: ModalService,
    private translate: TranslateService,
    private profileService: ProfileService,
    private utilService: UtilityService,
    private activeModal: NgbActiveModal,
    private router: Router,
    private messageService: MessageService,
    private fb: FormBuilder
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1),
      per_page: new FormControl(60),
    });
  }

  ngOnInit(): void {
    this.activityDetails();
    this.user = this.startupService.getUser();
  }

  activityDetails() {
    this.route.paramMap.subscribe((params) => {
      const slug = params.get('slug');
      this.activityService.details(slug).subscribe((res) => {
        this.activity = res;

        this.tabs[0].title = `ILS PARTICIPENT ${this.activity.participants_count}/${this.activity.max_participants}`;

        this.center = {
          lat: this.activity.latitude,
          lng: this.activity.longitude,
        };

        this.eventId = this.activity.id;
        this.organizerDetails = this.activity.organizer;
        this.theme = this.activity.theme;
        this.eventStatus();
        this.checkIfOrganizer();
        this.participantions();
        this.memberComments();
        this.waitingList();
        this.invitedList();
        this.myPicture();
      });
    });
  }

  tabClicked(e: ITabs) {
    this.type = e.key;
  }

  checkIfOrganizer() {
    const user = this.startupService.getUser();
    this.organizer =
      user && user.id === this.organizerDetails.id ? true : false;
  }

  eventStatus() {
    this.activityService
      .relationship(this.organizerDetails.id)
      .subscribe((res) => {
        this.userStatus = res;
      });
  }

  participantions() {
    this.filterForm.addControl('status', this.fb.array([]));
    const statusArray = this.filterForm.get('status') as FormArray;
    statusArray.push(new FormControl('organizing'));
    statusArray.push(new FormControl('attending'));

    const query = this.utilService.serialize(this.filterForm.value);
    this.filterForm.removeControl('status');

    this.activityService
      .participations(this.eventId, query)
      .subscribe((res) => {
        this.participants = res;
        console.log(this.participants);
      });
  }

  waitingList() {
    this.filterForm.addControl('status', new FormControl('waiting_list'));
    const query = this.utilService.serialize(this.filterForm.value);
    this.filterForm.removeControl('status');

    this.activityService.waiting(this.eventId, query).subscribe((res) => {
      this.waitingParticipants = res.body;
    });
  }

  invitedList() {
    this.filterForm.addControl('status', new FormControl('invited'));
    const query = this.utilService.serialize(this.filterForm.value);
    this.filterForm.removeControl('status');

    this.activityService.invited(this.eventId, query).subscribe((res) => {
      this.invitedParticipants = res.body;
      this.tabs[1].title = `INVITÉS ${res.body.length}`;
    });
  }

  memberComments() {
    this.activityService.comments(this.eventId).subscribe((res) => {
      this.comments = res;
      console.log(res);
    });
  }

  receiveSubComment($event: any, ind: number) {
    this.comments[ind].commentText = $event;
  }

  commentResponse(id: number, index: number) {
    if (this.comments[index].responses) {
      delete this.comments[index].responses;
      this.comments[index].is_commenting = false;
    } else {
      this.activityService.commentChildren(id).subscribe((res) => {
        this.comments[index].responses = res;
      });
    }
  }

  participate(id: number) {
    this.activityService.participation(id).subscribe((res) => {
      if (res.status === 'attending') {
        this.activityDetails();
        this.modalService.participate();
      }
    });
  }

  cancelParticipation(id: number) {
    const title = this.translate.instant(
      'events.modals.removeParticipation.title'
    );
    const message = '';
    const icon = 'trash-icon';
    const confirm = this.translate.instant(
      'events.modals.removeParticipation.confirmButton'
    );
    const cancel = this.translate.instant(
      'events.modals.removeParticipation.cancelButton'
    );

    this.modalService
      .confirmation(title, message, icon, confirm, cancel)
      .then((res) => {
        this.activityService.cancelParticipation(id).subscribe((res) => {
          this.activityDetails();
          setTimeout(() => {
            this.messageService.sendMessage({
              type: APP.MESSAGE.FLASH_MESSAGE,
              data: {
                message: this.translate.instant(
                  'notifications.flash.events.details.participationRemoved'
                ),
              },
            });
          }, 500);
        });
      })
      .catch(() => {
        console.log('err');
      });
  }

  publishComment(id: number) {
    this.activityService.addComment(id, this.commentText).subscribe((res) => {
      this.commentText = '';
      this.memberComments();
    });
  }

  publishCommentSub(id: number, ind: number) {
    this.activityService
      .postCommentChildren(id, this.comments[ind].commentText)
      .subscribe((res) => {
        this.activityDetails();
      });
  }

  accecptInvitaion(id: number) {
    this.activityService.invitation(id, 'accepted').subscribe((res) => {
      this.activityDetails();
    });
  }

  rejectInvitaion(id: number) {
    this.activityService.invitation(id, 'declined').subscribe((res) => {
      this.activityDetails();
    });
  }

  myPicture() {
    this.filterForm.get('per_page')?.setValue(20);
    const query = this.utilService.serialize(this.filterForm.value);
    this.activityService.pictures(this.eventId, query).subscribe((res) => {
      this.totalItems = res.headers.get('x-total');
      this.pictures = res.body;
    });
  }

  deletePicture(id: number) {
    const title = this.translate.instant(
      'userAccount.profile.modals.confirmRemovePicture.title'
    );
    const message = '';
    const icon = 'alert-icon';
    const confirm = this.translate.instant(
      'userAccount.profile.modals.confirmRemovePicture.button'
    );
    const cancel = this.translate.instant(
      'userAccount.profile.modals.confirmRemovePicture.cancel'
    );
    this.modalService
      .confirmation(title, message, icon, confirm, cancel)
      .then((res) => {
        this.profileService.deletePicture(id).subscribe((res) => {
          this.activityDetails();
          setTimeout(() => {
            this.messageService.sendMessage({
              type: APP.MESSAGE.FLASH_MESSAGE,
              data: {
                message: this.translate.instant(
                  'notifications.flash.events.details.pictureRemoved'
                ),
              },
            });
          }, 500);
        });
      })
      .catch(() => {
        console.log('err');
      });
  }

  viewPhoto(index: number, picId: number) {
    this.modalService.previewPhoto(this.pictures, index, picId);
  }

  uploadImage(e: any) {
    const formData = new FormData();
    formData.append('picture', e.file, e.filename);

    this.activityService.addPicture(this.eventId, formData).subscribe((res) => {
      this.activeModal.close();
      this.myPicture();
    });
  }

  reportActivity() {
    this.modalService.abusiveContent();
  }

  openInvitationModal() {
    this.modalService.sendInvitation(this.eventId);
  }

  deleteEvent() {
    const title = this.translate.instant(
      'events.modals.confirmCancelEvent.title'
    );
    const message = this.translate.instant(
      'events.modals.confirmCancelEvent.content'
    );
    const icon = 'trash-icon';
    const confirm = this.translate.instant(
      'events.modals.confirmCancelEvent.confirmButton'
    );
    const cancel = this.translate.instant(
      'events.modals.confirmCancelEvent.cancelButton'
    );
    this.modalService
      .confirmation(title, message, icon, confirm, cancel)
      .then((res) => {
        this.activityService.deleteEvent(this.eventId).subscribe((res) => {
          this.router.navigateByUrl('/groupes/activites');
          setTimeout(() => {
            this.messageService.sendMessage({
              type: APP.MESSAGE.FLASH_MESSAGE,
              data: {
                message: this.translate.instant(
                  'notifications.flash.events.details.deletedEvent'
                ),
              },
            });
          }, 500);
        });
      })
      .catch(() => {
        console.log('error');
      });
  }

  updatePagination(e: any) {}

  downloadParticipantList() {
    const path = this.activityService.getParticipantsList(this.eventId);
    window.open(path, '_blank');
    window.focus();
  }

  receive(event: any) {
    this.commentText = event;
  }
}
