import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { Options } from 'ngx-google-places-autocomplete/objects/options/options';

@Component({
  selector: 'app-address-dropdown',
  templateUrl: './address-dropdown.component.html',
  styleUrls: ['./address-dropdown.component.scss']
})
export class AddressDropdownComponent {
  options: Options = new Options({
    types: ['(cities)'],
    componentRestrictions: { country: 'FR' }
  });
  @Output() addresChanged: EventEmitter<Address> = new EventEmitter();
  @Input() defaultValue = '';
  constructor() {
  }

  handleAddressChange(e: Address) {
    this.addresChanged.emit(e);
  }

}
