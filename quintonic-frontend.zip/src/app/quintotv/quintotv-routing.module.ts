import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuintotvRootComponent } from './quintotv-root.component';
import { QuintotvComponent } from './quintotv/quintotv.component';

const routes: Routes = [
  {
    path: '',
    component: QuintotvRootComponent,
    children: [{
      path: '',
      component: QuintotvComponent
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuintotvRoutingModule { }
