import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { ISearchData } from '../interface/interface';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnInit {
  data!: ISearchData;
  query = '';
  constructor(
    private homeService: HomeService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.query = params['query'];
      this.loadData();
    });
  }

  loadData() {
    this.homeService.searchList(this.query).subscribe((res) => {
      console.log(res);
      this.data = res;
    });
  }
}
