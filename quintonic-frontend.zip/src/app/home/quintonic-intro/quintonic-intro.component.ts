import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { MessageService } from 'src/app/shared/services/message/message.service';
import { ValidationService } from 'src/app/shared/services/validations/validations.sevice';
import { APP } from 'src/app/shared/constant/app.constant';
@Component({
  selector: 'app-quintonic-intro',
  templateUrl: './quintonic-intro.component.html',
  styleUrls: ['./quintonic-intro.component.scss'],
})
export class QuintonicIntroComponent implements OnInit {
  invitationForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private homeService: HomeService,
    private messageService: MessageService,
    private translate: TranslateService
  ) {
    this.invitationForm = this.formBuilder.group({
      emails: this.formBuilder.array([this.createEmailField()]),
    });
  }

  ngOnInit(): void {}

  get emails() {
    return this.invitationForm.get('emails') as FormArray;
  }

  createEmailField(): FormGroup {
    return this.formBuilder.group({
      email: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.emailValidator,
          this.validationService.maxlengthValidator('email', 320),
        ],
      ],
    });
  }

  addEmail() {
    this.emails.push(this.createEmailField());
  }

  removeEmail(index: number) {
    this.emails.removeAt(index);
  }

  onSubmit() {
    if (!this.invitationForm.valid) return;
    const emails = this.emails.value.map(
      (emailGroup: { email: string }) => emailGroup.email
    );
    console.log('Emails:', emails);
    this.homeService.sponsorship_invitations(emails).subscribe(() => {
      this.invitationForm.reset();
      setTimeout(() => {
        this.messageService.sendMessage({
          type: APP.MESSAGE.FLASH_MESSAGE,
          data: {
            message: this.translate.instant(
              'notifications.flash.sponsorship.success'
            ),
          },
        });
      }, 500);
    });
  }

  onCancel() {
    this.invitationForm.reset();
  }
}
