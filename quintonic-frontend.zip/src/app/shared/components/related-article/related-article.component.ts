import { Component, Input, OnInit } from '@angular/core';
import { IArticalDetails } from 'src/app/magazine/interface/interface';

@Component({
  selector: 'app-related-article',
  templateUrl: './related-article.component.html',
  styleUrls: ['./related-article.component.scss']
})
export class RelatedArticleComponent implements OnInit {

  @Input() relatedArticle: IArticalDetails[] = []

  constructor() { }

  ngOnInit(): void {
  }

}
