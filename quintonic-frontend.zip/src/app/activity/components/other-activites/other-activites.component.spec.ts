import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherActivitesComponent } from './other-activites.component';

describe('OtherActivitesComponent', () => {
  let component: OtherActivitesComponent;
  let fixture: ComponentFixture<OtherActivitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherActivitesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OtherActivitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
