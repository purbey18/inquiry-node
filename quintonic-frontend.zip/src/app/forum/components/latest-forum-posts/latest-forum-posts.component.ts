import { Component, OnInit } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { FormControl, FormGroup } from '@angular/forms';
import { IPosts } from '../../interface/interface';

@Component({
  selector: 'app-latest-forum-posts',
  templateUrl: './latest-forum-posts.component.html',
  styleUrls: ['./latest-forum-posts.component.scss'],
})
export class LatestForumPostsComponent implements OnInit {
  posts: IPosts[] = [];
  filterForm: FormGroup;
  constructor(
    private ForumService: ForumService,
    private utilService: UtilityService) {
    this.filterForm = new FormGroup({
      page: new FormControl(1, []),
      per_page: new FormControl(5, []),
      order_by: new FormControl('last_comment', []),
    });
  }

  ngOnInit(): void {
    this.load();
  }

  load() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.ForumService.posts(query).subscribe((res) => {
      this.posts = res.body;
    });
  }
}
