import { Component, OnInit } from '@angular/core';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { ILastPostActivity } from '../../interface/interface';
import { FormGroup, FormControl } from '@angular/forms';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';

@Component({
  selector: 'app-latest-post-activity',
  templateUrl: './latest-post-activity.component.html',
  styleUrls: ['./latest-post-activity.component.scss'],
})
export class LatestPostActivityComponent implements OnInit {

  lastPostActivies: ILastPostActivity[] = [];
  filterForm: FormGroup
  constructor(
    private activityService: ActivityService,
    private utilService: UtilityService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1),
      per_page: new FormControl(5),
      order_by: new FormControl('publication_date'),
      period: new FormControl('upcoming')
    });
  }

  ngOnInit(): void {
    this.latestPost();
  }

  latestPost() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.activityService.latestPostActivity(query).subscribe((res) => {
      this.lastPostActivies = res;
    });
  }
}
