import { FavoriteCity, IUser } from "src/app/shared/interfaces/common";

export interface IForum {
  id: number;
  title: string;
  body: string;
  slug: string;
  last_comment?: LastComment;
  comments_count: number;
  created_at: string;
  is_favorite: boolean;
  is_sticky: boolean;
  user: IUser;
  forum_theme: ForumTheme;
  favorite_city: FavoriteCity;
}

export interface LastComment {
  created_at: string;
  user: string;
}

export interface User {
  age?: number;
  avatar: Avatar;
  biography?: string;
  city?: string;
  created_at: string;
  distance: any;
  gender: string;
  id: number;
  mood: any;
  slug: string;
  updated_at: string;
  user_name: string;
  mutual_hobbies: any[];
  hobbies: Hobby[];
  loves?: string;
  hates?: string;
  looking_for?: string;
  is_premium: boolean;
}

export interface Avatar {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}
export interface ForumTheme {
  id: number;
  name: string;
  slug: string;
  picture: Picture;
  forum_seo_block: any;
}

export interface Hobby {
  id: number;
  name: string;
  theme_id?: number;
}

interface Picture {
  large: string;
  small: string;
}

export interface IForumMainListing {
  id: number;
  name: string;
  slug: string;
  picture: Picture;
  forum_seo_block: string;
}

export interface IPosts {
  id: number;
  title: string;
  body: string;
  slug: string;
  last_comment: LastComment;
  comments_count: number;
  created_at: string;
  is_favorite: boolean;
  is_sticky: boolean;
  user: IUser;
  forum_theme: ForumTheme;
  favorite_city: FavoriteCity;
}

export interface LastComment {
  created_at: string;
  user: string;
}

export interface User {
  age?: number;
  avatar: Avatar;
  biography?: string;
  city?: string;
  created_at: string;
  distance: any;
  gender: string;
  id: number;
  mood: any;
  slug: string;
  updated_at: string;
  user_name: string;
  mutual_hobbies: any[];
  hobbies: Hobby[];
  loves?: string;
  hates?: string;
  looking_for?: string;
  is_premium: boolean;
}

export interface Avatar {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}

export interface ForumTheme {
  id: number;
  name: string;
  slug: string;
  picture: Picture;
  forum_seo_block: any;
}

export interface IComments {
  id: number
  body: string
  has_children: boolean
  children_count: number
  created_at: string
  updated_at: string
  has_parent: boolean
  discussion: IForum
  user?: IUser
  parent: any;
  allComments: string[]
}