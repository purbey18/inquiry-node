import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IUser } from 'src/app/shared/interfaces/common';
import { StartupService } from 'src/app/shared/services/startup/startup.service';

@Component({
  selector: 'app-comment-textarea',
  templateUrl: './comment-textarea.component.html',
  styleUrls: ['./comment-textarea.component.scss']
})
export class CommentTextareaComponent implements OnInit {
  @Input()commentText: string = '';
  @Output() commentEmit: EventEmitter<any> = new EventEmitter();

  showEmojiPicker: boolean =false;
  user!: IUser;

  constructor(
    private startUpService: StartupService
  ) { }

  ngOnInit(): void {

    this.user = this.startUpService.getUser()
  }
  addEmoji(event: any) {
    console.log(this.commentText)
    const { commentText } = this;
    console.log(commentText);
    console.log(`${event.emoji.native}`)
    const text = `${commentText}${event.emoji.native}`;

    this.commentText = text;
    this.showEmojiPicker = false;
    this.commentEmit.emit(this.commentText);

  }
  openPicker(){
    this.showEmojiPicker = !this.showEmojiPicker;
    console.log(this.showEmojiPicker);
    
  }
  comment(){
    this.commentEmit.emit(this.commentText);
  }

}
