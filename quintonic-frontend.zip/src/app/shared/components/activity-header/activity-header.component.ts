import { Component, OnInit } from '@angular/core';
import { StartupService } from '../../services/startup/startup.service';
import { IUser } from '../../interfaces/common';
@Component({
  selector: 'app-activity-header',
  templateUrl: './activity-header.component.html',
  styleUrls: ['./activity-header.component.scss']
})
export class ActivityHeaderComponent implements OnInit {
  profile!: IUser;
  constructor(
    private startupService: StartupService
  ) { }

  ngOnInit(): void {
    this.profile = this.startupService.getUser();
  }

}
