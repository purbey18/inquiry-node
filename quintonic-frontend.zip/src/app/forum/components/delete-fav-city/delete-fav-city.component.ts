import { Component, OnInit, ViewChild } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';
import { FavoriteCity } from 'src/app/shared/interfaces/common';
@Component({
  selector: 'app-delete-fav-city',
  templateUrl: './delete-fav-city.component.html',
  styleUrls: ['./delete-fav-city.component.scss']
})
export class DeleteFavCityComponent implements OnInit {
  favCities: FavoriteCity[] = [];
  cityId!: number;
  model: any;
  constructor(
    private forumService: ForumService,
    private activeModal: NgbActiveModal
  ) { }

  @ViewChild('instance', { static: true }) instance!: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();
  search: any = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
    const inputFocus$ = this.focus$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term) =>
        (term === '' ? this.favCities : this.favCities.filter((v) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10),
      ),
    );
  };

  formatter = (x: { name: string }) => x.name;

  ngOnInit(): void {
    this.favoriteCity()
  }

  removeFavCity() {
    this.forumService.revomeFavCity(this.cityId).subscribe((res) => {
      console.log('res:', res)
      this.activeModal.close()
    })
  }

  favoriteCity() {
    this.forumService.favoriteCities().subscribe((res: FavoriteCity[]) => {
      this.favCities = [...new Map(res.map(city => [city.id, city])).values()];
    })
  }

  selectedCity(e: any) {
    this.cityId = e.id
    console.log('choose:', e)
  }
}
