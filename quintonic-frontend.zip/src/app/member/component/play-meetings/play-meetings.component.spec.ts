import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayMeetingsComponent } from './play-meetings.component';

describe('PlayMeetingsComponent', () => {
  let component: PlayMeetingsComponent;
  let fixture: ComponentFixture<PlayMeetingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlayMeetingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlayMeetingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
