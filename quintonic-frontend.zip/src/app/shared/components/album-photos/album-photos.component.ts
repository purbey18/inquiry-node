import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { ProfileService } from '../../services/profile/profile.service';
import { IPicture } from '../../interfaces/profile';
import { ModalService } from '../../services/modal/modal.service';
import { ActivityService } from '../../services/activity/activity.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-album-photos',
  templateUrl: './album-photos.component.html',
  styleUrls: ['./album-photos.component.scss']
})
export class AlbumPhotosComponent implements OnInit {

  filterForm: FormGroup;
  pictures: IPicture[] = []
  totalItems = 0;

  constructor(
    private profileSerice: ProfileService,
    private utilService: UtilityService,
    private modalService: ModalService,
    private activityService: ActivityService,
    private activeModal: NgbActiveModal
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1, []),
      per_page: new FormControl(20, []),
      order_by: new FormControl('creation_date', [])
    });
  }

  ngOnInit(): void {
    this.albumPictures()
  }

  albumPictures() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.profileSerice.picture(query).subscribe((res) => {
      this.pictures = res.body
      this.totalItems = res.headers.get('x-total');
    })
  }

  slectedImage(selectedImage: IPicture) {
    this.modalService.addPhoto(selectedImage).then((res) => {
      console.log('RESPNSE:' , res)
      // const formData = new FormData();
      // formData.append('picture', res.picture.id);
      // this.activityService.addPicture(this.eventId, formData).subscribe((res) => {
      //   this.activeModal.close()
      // })
    })
    .catch(() => console.log('cancel'));
  }

  updatePagination(e: any) {
    this.filterForm.get('page')?.setValue(e);
    this.albumPictures();
  }
}
