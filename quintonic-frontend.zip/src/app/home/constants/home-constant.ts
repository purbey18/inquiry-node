export const HOME = {
    BENEFITS: [
        {
            title: '1500 activities offered each month',
            discription: 'Varied and often free activities to share in real life and on the site.'
        },
        {
            title: '140,000 members throughout France',
            discription: 'Rennes, Montpellier, Metz, Rouen… There are bound to be Quintonic members near you.'
        },
        {
            title: 'Friendly and romantic encounters made by affinity',
            discription: 'With Quintonic, meet the people who really look like you.'
        },
        {
            title: 'With our online magazine, finally information that concerns you',
            discription: 'Health, leisure or managing your finances, all the subjects that concern you.'
        }
    ],
    ENGAGEMENTS: ["Secure payment", "Verified Profiles", "Vibrant community"],
    PAGE_INFO_BLOCK: [
        {
            title: `More than 1,500 activities are submitted by members each month. You
            will be very busy!`,
            description: `Explore new horizons through adapted and varied activities outside
            your home. With a large catalog of suggestions for outings offered
            by members all over France, make friendly encounters in a new
            setting! On Quintonic, you will find companions both for your active
            walking outings and also for your evenings at the theatre. Do you
            have a passion for handmade? Participate in the many artistic and
            fun workshops offered by members. And many more ideas!<br /><br />
            • Shows and entertainment,<br />
            • Artistic workshops and creative hobbies,<br />
            • Sports outings and nature outings,<br />
            • Well-being.<br />`,
            image: `assets/images/home3.jpg`,
            btnText: `Discover the activities`,
            alt: `activites seniors sur Quintonic`,
            tooltip: `activites seniors sur Quintonic`,
            class: `grey`,
            link: '/activity'
        }, {
            title: `Two is even better! Quintonic is also l'Instant Rencontre, a
            friendly dating site (or more if affinities) online`,
            description: `To chat with new friends and perhaps find new love, organize paying
            or private activities, become one of our PREMIUM members! You will
            be able to compare your profile and your expectations with those of
            the 140,000 other members of the community whose profiles have been
            verified to guarantee you quality exchanges and meetings. Take
            advantage of it, the subscription is without commitment of duration.
            Have you found the shoe that suits you? You can unsubscribe at any
            time free of charge.`,
            image: `assets/images/home5.jpg`,
            btnText: `Discover Instant Meeting`,
            alt: `activites seniors sur Quintonic`,
            tooltip: `activites seniors sur Quintonic`,
            class: `grey`,
            link: '/activity'
        }, {
            title: `Stay up to date with senior news with our online magazine`,
            description: `Our digital magazine brings you plenty of answers and solutions to
            the questions that animate your daily life. Find ideal sports
            activities according to your age; better anticipate retirement or
            even know how to use homeopathy to treat minor daily ailments... A
            gold mine of information that concerns you.`,
            image: `assets/images/home4.jpg`,
            btnText: `Discover the magazine`,
            alt: `mains sur un ordinateur`,
            tooltip: `mains sur un ordinateur`,
            class: 'flex-row-reverse',
            link: ''
        }, {
            title: `Watch premium video content that matters to you on QUINTO TV`,
            description: `Find all the useful information for your daily life in an
            interactive format that is updated regularly. Already more than 300
            online sports sessions are available on QUINTO TV: Pilates, yoga,
            dance, stretching, cardio, abdominals, HIIT, self-massage,
            respiratory tao. You will also find video presentations by
            professionals from different sectors on the issues that interest you
            and concern you: finance, pensions, well-being, culture, cooking,
            and many other topics. These videos are unlimited accessible for
            PREMIUM members only. Don't wait any longer, become a member!`,
            image: `assets/images/home8.png`,
            btnText: `Discover the Quinto TV`,
            alt: `activites seniors sur Quintonic`,
            tooltip: `activites seniors sur Quintonic`,
            class: 'grey',
            link: ''
        }
    ]
}