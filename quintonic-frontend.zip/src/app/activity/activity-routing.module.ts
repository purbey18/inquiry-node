import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActivityRootComponent } from './activity-root.component';
import { ActivityComponent } from './activity/activity.component';
import { StepOneComponent } from './add-activity/step-one/step-one.component';
import { StepThreeComponent } from './add-activity/step-three/step-three.component';
import { StepTwoComponent } from './add-activity/step-two/step-two.component';
import { DetailComponent } from './detail/detail.component';
import { CreateActivityComponent } from './create-activity/create-activity.component';

const routes: Routes = [
  {
    path: '',
    component: ActivityRootComponent,
    children: [
      {
        path: 'activites',
        component: ActivityComponent
      },
      {
        path: 'activites/new',
        component: CreateActivityComponent
      },
      {
        path: ':city/:slug',
        component: DetailComponent
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActivityRoutingModule { }
