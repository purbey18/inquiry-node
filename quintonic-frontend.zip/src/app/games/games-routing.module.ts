import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GamesRootComponent } from './games-root.component';
import { GamesComponent } from './games/games.component';
import { DetailComponent } from './detail/detail.component';

const routes: Routes = [
  {
    path: '',
    component: GamesRootComponent,
    children: [
      {
        path: '',
        component: GamesComponent,
      },
      {
        path: ':slug',
        component: DetailComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GamesRoutingModule { }
