import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TheyChooseComponent } from './they-choose.component';

describe('TheyChooseComponent', () => {
  let component: TheyChooseComponent;
  let fixture: ComponentFixture<TheyChooseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TheyChooseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TheyChooseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
