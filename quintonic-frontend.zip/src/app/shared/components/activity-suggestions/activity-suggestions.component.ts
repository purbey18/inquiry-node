import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject, debounceTime, distinctUntilChanged, filter, map, merge } from 'rxjs';
import { ActivityService } from '../../services/activity/activity.service';
import { ITheme } from '../../interfaces/common';

@Component({
  selector: 'app-activity-suggestions',
  templateUrl: './activity-suggestions.component.html',
  styleUrls: ['./activity-suggestions.component.scss']
})
export class ActivitySuggestionsComponent implements OnInit {
  model: any;
  @ViewChild('instance', { static: true }) instance!: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();
  search: any = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(
      debounceTime(200),
      distinctUntilChanged()
    );
    const clicksWithClosedPopup$ = this.click$.pipe(
      filter(() => !this.instance.isPopupOpen())
    );
    const inputFocus$ = this.focus$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term) =>
        (term === ''
          ? this.themes
          : this.themes.filter(
              (v) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1
            )
        ).slice(0, 10)
      )
    );
  };
  themes: ITheme[] = [];
  @Output() selectedItem = new EventEmitter<ITheme>();
  constructor(
    private activityService: ActivityService
  ) { }

  ngOnInit(): void {
    this.activityService.theme()
    .subscribe(res => {
      this.themes = res;
    });
  }

  formatter = (x: { name: string }) => x.name;

  itemChoose(item: any) {
    console.log('itemSelected');
    console.log(item);
    this.selectedItem.emit(item);
  }
}
