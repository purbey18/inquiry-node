import { Component, OnInit } from '@angular/core';
import { IArtical, ICategories, ISubCategories } from 'src/app/activity/interface/interface';
import { ArticalService } from 'src/app/shared/services/artical/artical.service';
import { IBreadcrumb } from '../interface/interface';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent implements OnInit {

  articals: IArtical[] = [];
  categories: ICategories[] = [];
  subcategories: ISubCategories[] = [];
  searchTerm: string = ''
  breadcrumbs: IBreadcrumb[] = []
  page!: number;
  per_page!: number;
  totalItems!: number;

  constructor(private ArticalService: ArticalService) { }

  ngOnInit(): void {
    this.artical();
    this.categorirs();
  }

  artical() {
    const params = {
      page: this.page,
      per_page: this.per_page,
      recent: true
    }
    this.ArticalService.getAllArtical(params).subscribe((res) => {
      const { headers, body } = res;
      this.articals = body;
      this.page = Number(headers.get('x-page'));
      this.per_page = Number(headers.get('x-per-page'));
      this.totalItems = Number(headers.get('x-total'));
    });
  }

  categorirs() {
    this.ArticalService.categories().subscribe((res) => {
      this.categories = res;
    });
  }

  getSubCategoriesAndArticle(category: any) {
    this.ArticalService.subCategories(category.id).subscribe((res) => {
      this.subcategories = res
    })
    this.ArticalService.filterByCategory(category.slug).subscribe((res) => {
      this.articals = res;
    })
  }

  searchArticle(e: any) {
    this.searchTerm = e.target.value
    this.ArticalService.searchArticle(this.searchTerm).subscribe((res) => {
      this.articals = res;
    })
  }

  updatePagination(e: any) {
    this.page = e
    this.artical()
  }
}
