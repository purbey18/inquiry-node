import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-root',
  templateUrl: './search-root.component.html',
  styleUrls: ['./search-root.component.scss']
})
export class SearchRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
