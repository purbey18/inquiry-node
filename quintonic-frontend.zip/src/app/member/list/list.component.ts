import { Component, OnInit } from '@angular/core';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { IMember } from 'src/app/member/interface/interface';
import { ACTIVITY } from 'src/app/activity/constants/activity-constant';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { FormControl, FormGroup } from '@angular/forms';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { Location } from '@angular/common';
import { ITag } from 'src/app/activity/interface/interface';
import { MEMBER } from '../constants/member-constant';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent implements OnInit {
  ACTIVITY_CONST = ACTIVITY;
  MEMBER_CONST = MEMBER;
  members: IMember[] = [];
  themes: any = [];
  tags: ITag[] = []
  totalItems = 50;
  filterForm: FormGroup;
  constructor(
    private MemberService: MemberService,
    private activityService: ActivityService,
    private utilityService: UtilityService,
    private location: Location
  ) {
    this.filterForm = new FormGroup({
      'age[maximum]': new FormControl('', []),
      'age[mimimum]': new FormControl('', []),
      born_today: new FormControl('', []),
      city: new FormControl('Paris, France', []),
      distance: new FormControl(this.ACTIVITY_CONST.RADIUS[2].value, []),
      gender: new FormControl('', []),
      order_by: new FormControl('last_connection', []),
      page: new FormControl(1, []),
      per_page: new FormControl(20, []),
      online: new FormControl('', []),
      friend_with_me: new FormControl('', []),
      user_name: new FormControl('', []),
      with_avatar: new FormControl('', []),
      with_mutual_events: new FormControl('', []),
      'tagged_with': new FormControl()
    });
  }

  setValue($event: any, controlName: string, valueLabel: string) {
    this.filterForm.get(controlName)?.setValue($event[valueLabel]);
    this.navigateTo();
  }

  navigateTo() {
    const query = this.utilityService.serialize(this.filterForm.value);
    this.location.replaceState('users', query);
    this.load();
  }

  ngOnInit(): void {
    this.load();
    this.theme();
  }

  load() {
    this.MemberService.list(this.filterForm.value).subscribe((res) => {
      console.log(res);
      this.members = res.body;
      this.totalItems = res.body.length
    });
  }

  theme() {
    this.activityService.theme().subscribe((res) => {
      this.themes = res;
      this.themes.unshift({ id: 0, name: 'All Activity' });
    });
  }

  addressChanged(e: any) {
    this.filterForm.get('city')?.setValue(e.formatted_address);
    this.navigateTo();
  }

  updatePagination(e: any) {
    this.filterForm.get('page')?.setValue(e);
    this.navigateTo();
  }

  advanceFilterUpdated(event: any) {
    console.log('Advance filter event:', event);
    for (let i in event) {
      if (i === 'tagged_with[]') {
        let items = [];
        for (let ii in event[i]) {
          if (event[i][ii]) {
            items.push(event[i][ii].id);
            this.tags.push(event[i][ii])
          }
        }
        this.filterForm.get('tagged_with')?.setValue(items)
      } else {
        this.filterForm.get(i)?.setValue(event[i]);
      }
    }
    this.navigateTo();
  }

  removeFilter(filedName: string) {
    this.filterForm.get(filedName)?.reset();
    this.navigateTo();
  }
}
