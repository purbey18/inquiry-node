import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChildren,
} from '@angular/core';
import { NgbDropdown, NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { IMember } from 'src/app/member/interface/interface';
import { APP } from 'src/app/shared/constant/app.constant';
import { IUser } from 'src/app/shared/interfaces/common';
import { HeaderService } from 'src/app/shared/services/header/header.service';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';

@Component({
  selector: 'app-friend-button',
  templateUrl: './friend-button.component.html',
  styleUrls: ['./friend-button.component.scss'],
})
export class FriendButtonComponent implements OnInit {
  @Input() user!: IUser;
  @ViewChildren(NgbDropdown) dropdowns: any;
  RELATIONSHIP_STATUS = APP.RELATIONSHIP;
  @Output() deleted: EventEmitter<any> = new EventEmitter();

  constructor(
    private memberService: MemberService,
    private modalService: ModalService,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {}
  deleteRequest() {
    this.memberService.deleteFriendRequest(this.user.id).subscribe({
      next: (res) => {
        console.log(res);
        this.dropdownClose();
        this.deleted.emit();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  rejectFriendRequest() {
    this.headerService.requestReject(this.user.id).subscribe({
      next: (res) => {
        this.user.relationship = res;
        this.dropdownClose();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  openRequestDialog() {
    this.dropdownClose();
    this.modalService.sendRequest(this.user);
  }
  dropdownClose() {
    this.dropdowns.toArray().forEach((el: any) => {
      el.close();
    });
  }

}
