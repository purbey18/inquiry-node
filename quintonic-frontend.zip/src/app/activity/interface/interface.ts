import { FavoriteCity, IOrganizer, IPicture, ITheme, IUser } from "src/app/shared/interfaces/common";

interface Picture {
  url: string;
}

export interface CoverPicture {
  thumb: string;
  small: string;
  large: string;
}


export interface Avatar {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}

export interface IActivity {
  id: number;
  type: string;
  slug: string;
  title: string;
  description: string;
  additional_information: string;
  gender_parity?: boolean;
  latitude: number;
  longitude: number;
  place: string;
  address: string;
  address_complement?: any;
  city: string;
  state?: string | null | undefined;
  postcode: string;
  country: string;
  starts_at?: Date | string;
  ends_at?: Date;
  max_participants: number;
  participants_count: number;
  interested_users_count: number;
  cover_picture: CoverPicture;
  privacy: any;
  published: boolean;
  participation_status?: any;
  tags: ITag;
  commercial: boolean;
  waiting_list_started?: boolean;
  theme: ITheme;
  favorite_city: FavoriteCity
  organizer: IOrganizer;
}

export interface IArtical {
  id: number;
  title: string;
  body: string;
  slug: string;
  picture: IPicture;
  created_at: Date;
  published_at?: Date;
  updated_at: Date;
  magazine_subcategory: MagazineSubcategory;
}

interface MagazineSubcategory {
  id: number;
  name: string;
  slug: string;
  picture: IPicture;
  parent: Parent;
  type: string;
  magazine_seo_block: string;
}

interface Parent {
  id: number;
  name: string;
  slug: string;
  picture: Picture3;
  parent?: any;
  type: string;
  magazine_seo_block: string;
}

interface Picture3 {
  large: string;
  small: string;
}

export interface ICategories {
  id: number;
  name: string;
  slug: string;
  picture: Picture;
  parent?: any;
  type: string;
  magazine_seo_block: string;
}
interface Picture {
  large: string;
  small: string;
}


export interface IFilter {
  city: string
  distance: number
  favorite_city_id: number
  friend_attending: number
  order_by: string
  page: number
  per_page: number
  period: string
  theme: string
  title: string
}

export interface ISubCategories {
  id: number
  name: string
  slug: string
  picture: Picture
  parent: Parent
  type: string
  magazine_seo_block: string
}


export interface ITag {
  id: number
  name: string
  theme_id: number
}

export interface ISuggestedPicture {
  id: number
  url: Picture
  theme_id: number
}
export interface ILastPostActivity {
  id: number
  type: string
  slug: string
  title: string
  description: string
  additional_information: any
  gender_parity?: boolean
  latitude: number
  longitude: number
  place: string
  address: string
  address_complement: any
  city: string
  state: string
  postcode: string
  country: string
  starts_at: string
  ends_at: any
  max_participants: number
  participants_count: number
  interested_users_count: number
  cover_picture: CoverPicture
  privacy: string
  published: boolean
  participation_status: string
  tags: any[]
  commercial: boolean
  waiting_list_started: boolean
  theme: Theme
  favorite_city: FavoriteCity
  organizer: Organizer
}
export interface CoverPicture {
  thumb: string
  small: string
  large: string
}
export interface Theme {
  id: number
  name: string
  slug: string
  picture: Picture
  events_seo_top_block: any
  events_seo_bottom_block: any
  meta_title: any
  meta_desc: any
}
export interface Picture1 {
  url: string
}

export interface Picture2 {
  large: string
  small: string
}

export interface Organizer {
  age: number
  avatar: Avatar
  biography: string
  city: string
  created_at: string
  distance: number
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: MutualHobby[]
  hobbies: any[]
  loves: string
  hates: string
  looking_for: string
  is_premium: boolean
}

export interface Avatar {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface MutualHobby {
  id: number
  name: string
  theme_id: number
}
export interface ILastMinute {
  id: number
  type: string
  slug: string
  title: string
  description: string
  additional_information: any
  gender_parity?: boolean
  latitude: number
  longitude: number
  place: string
  address: string
  address_complement: any
  city: string
  state: string
  postcode: string
  country: string
  starts_at: string
  ends_at: any
  max_participants: number
  participants_count: number
  interested_users_count: number
  cover_picture: CoverPicture
  privacy: string
  published: boolean
  participation_status: string
  tags: any[]
  commercial: boolean
  waiting_list_started: boolean
  theme: Theme
  favorite_city: FavoriteCity
  organizer: Organizer
}

export interface CoverPicture {
  thumb: string
  small: string
  large: string
}

export interface Theme {
  id: number
  name: string
  slug: string
  picture: Picture
  events_seo_top_block: any
  events_seo_bottom_block: any
  meta_title: any
  meta_desc: any
}
export interface Picture2 {
  large: string
  small: string
}

export interface Organizer {
  age: number
  avatar: Avatar
  biography: string
  city: string
  created_at: string
  distance: number
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: MutualHobby[]
  hobbies: any[]
  loves: string
  hates: string
  looking_for: string
  is_premium: boolean
}

export interface Avatar {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface MutualHobby {
  id: number
  name: string
  theme_id: number
}
export interface IParticipant {
  id: number
  status: string
  participant: IUser
  event: Event
}

export interface Participant {
  age: number
  avatar: Avatar
  biography: string
  city: string
  created_at: string
  distance: number
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: MutualHobby[]
  hobbies: Hobby[]
  loves: string
  hates: string
  looking_for?: string
  is_premium: boolean
}
export interface Hobby {
  id: number
  name: string
  theme_id: number
}
export interface IComment {
  id: number
  body: string
  has_children: boolean
  children_count: number
  created_at: string
  updated_at: string
  has_parent: boolean
  organized_event: OrganizedEvent
  user: IUser
  parent: any
  responses: any;
  is_commenting: boolean;
  commentText: string;
}
export interface OrganizedEvent {
  id: number
  type: string
  slug: string
  title: string
  description: string
  additional_information: any
  gender_parity: boolean
  latitude: number
  longitude: number
  place: string
  address: string
  address_complement: any
  city: string
  state: string
  postcode: string
  country: string
  starts_at: string
  ends_at: any
  max_participants: number
  participants_count: number
  interested_users_count: number
  cover_picture: CoverPicture
  privacy: string
  published: boolean
  participation_status: any
  tags: any[]
  commercial: boolean
  waiting_list_started: boolean
  theme: Theme
  favorite_city: FavoriteCity
  organizer: Organizer
}
export interface IEventStatus {
  id: number
  status: string
  fetched_at: any
  read_at: any
}

export interface IBooks {
  id: number
  type: string
  name: string
}