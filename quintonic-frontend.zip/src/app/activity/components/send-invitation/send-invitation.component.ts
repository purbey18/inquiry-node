import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { APP } from 'src/app/shared/constant/app.constant';
import { IUser } from 'src/app/shared/interfaces/common';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { MessageService } from 'src/app/shared/services/message/message.service';

@Component({
  selector: 'app-send-invitation',
  templateUrl: './send-invitation.component.html',
  styleUrls: ['./send-invitation.component.scss']
})
export class SendInvitationComponent implements OnInit {

  @Input() eventId! : number

  inviteAllFriends!: '';
  selectedFriends: IUser[] = [];
  suggestedFriends: IUser[] = [];
  myFriends:IUser[] = []
  searchTerm = ''
  message = ''
  
  constructor(
    public activeModal : NgbActiveModal,
    private activityService : ActivityService,
    private messageService : MessageService,
    private translate : TranslateService
  ) { }

  ngOnInit(): void {
  }

  toggleFriends() {
    if (this.inviteAllFriends) {
      this.activityService.friendsList().subscribe((res) => {
        this.myFriends = res
        this.selectedFriends.push(...this.myFriends)
      })
    }
    else {
      this.selectedFriends = this.selectedFriends.filter(friend => !this.myFriends.includes(friend));
    }
  }

  searchUser(){
    this.activityService.searchUser(this.searchTerm).subscribe((res) => {
      this.suggestedFriends = res
    })
  }

  removeFriend(index : number){
    this.selectedFriends.splice(index, 1);
  }

  addFriend(user : IUser){
    this.searchTerm = ''
    if (!this.selectedFriends.some(friend => friend.id === user.id)) {
      this.selectedFriends.push(user);
    }
  }

  sendInvitation() {
    const user_ids = this.selectedFriends.map(friend => friend.id);
    const obj = this.message ? { user_ids, message: this.message } : { user_ids };
    this.activityService.inviteFriends(this.eventId, obj).subscribe((res) => {
      console.log(res)
      this.activeModal.close()
      setTimeout(() => {
        this.messageService.sendMessage({ type: APP.MESSAGE.FLASH_MESSAGE, data: { message: this.translate.instant('notifications.flash.events.inviteParticipants.success') } });
      }, 500);
    })
  }
}
