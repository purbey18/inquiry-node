import { Component, OnInit } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-fav-city',
  templateUrl: './add-fav-city.component.html',
  styleUrls: ['./add-fav-city.component.scss']
})
export class AddFavCityComponent implements OnInit {

  cityId!: number;
  constructor(
    private forumService: ForumService,
    private activeModal: NgbActiveModal
  ) { }

  ngOnInit(): void {
  }

  selectedCity(e: any) {
    console.log('city:', e)
    this.cityId = e.id
  }

  addCity() {
    this.forumService.addFavCity(this.cityId).subscribe((res) => {
      console.log('res:', res)
      this.activeModal.close()
    })
  }

}
