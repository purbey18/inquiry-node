import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscoverProfileComponent } from './discover-profile.component';

describe('DiscoverProfileComponent', () => {
  let component: DiscoverProfileComponent;
  let fixture: ComponentFixture<DiscoverProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiscoverProfileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DiscoverProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
