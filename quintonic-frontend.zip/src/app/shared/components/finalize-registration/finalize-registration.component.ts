import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from '../../services/modal/modal.service';
import { UserService } from '../../services/user/user.service';
import { environment } from 'src/environments/environment';
import { AuthService } from '../../services/auth/auth.service';
import { Router } from '@angular/router';
import { MessageService } from '../../services/message/message.service';
import { APP } from '../../constant/app.constant';

@Component({
  selector: 'app-finalize-registration',
  templateUrl: './finalize-registration.component.html',
  styleUrls: ['./finalize-registration.component.scss']
})
export class FinalizeRegistrationComponent implements OnInit {
  @Input() email: any
  constructor(
    public modalService: ModalService,
    public activeModal: NgbActiveModal,
    private userService: UserService,
    private authService: AuthService,
    private router: Router,
    private messageService: MessageService
  ) { }

  ngOnInit(): void {
  }

  goToModifyEmail(email: string) {
    this.activeModal.close();
    this.modalService.modifyEmail(email);
  }

  resendEmail() {
    this.userService.confimation(
      {
        resend_confirmation_instructions: true,
        confirm_success_url: environment.confirm_success_url,
        config_name: "default"
      }).subscribe(res => {
        console.log(res);
      });
  }

  signout() {
    this.userService.signout()
      .subscribe({
        next: res => {
          console.log(res);
          this.messageService.sendMessage({ type: APP.MESSAGE.SIGN_OUT });
          this.activeModal.close();
          this.authService.clearUserPreference();
          this.router.navigateByUrl('/groupes/activites');
        }
      })
  }

}
