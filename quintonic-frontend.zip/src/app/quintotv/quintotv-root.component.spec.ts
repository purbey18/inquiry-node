import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuintotvRootComponent } from './quintotv-root.component';

describe('QuintotvRootComponent', () => {
  let component: QuintotvRootComponent;
  let fixture: ComponentFixture<QuintotvRootComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuintotvRootComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuintotvRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
