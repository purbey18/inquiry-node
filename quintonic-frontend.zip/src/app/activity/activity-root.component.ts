import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-root',
  templateUrl: './activity-root.component.html',
  styleUrls: ['./activity-root.component.scss']
})
export class ActivityRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
