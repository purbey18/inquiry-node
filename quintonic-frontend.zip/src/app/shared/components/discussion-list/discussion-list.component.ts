import { Component, Input, OnInit } from '@angular/core';
import { IForumDiscussion } from '../../interfaces/common';
import { ForumService } from '../../services/forum/forum.service';

@Component({
  selector: 'app-discussion-list',
  templateUrl: './discussion-list.component.html',
  styleUrls: ['./discussion-list.component.scss'],
})
export class DiscussionListComponent implements OnInit {
  @Input() discussions: IForumDiscussion[] = [];
  constructor(private forumService: ForumService) { }

  ngOnInit(): void { }

  addFavourite(discussion_id: number) {
    this.forumService
      .addFavoritesDiscussion({ discussion_id })
      .subscribe(() => {
        const discussion = this.discussions.find(d => d.id === discussion_id);
        if (discussion) {
          discussion.is_favorite = true;
        }
      });
  }

  removeFavourite(discussion_id: number) {
    this.forumService
      .removeFavoriteDiscussion(discussion_id)
      .subscribe(() => {
        const discussion = this.discussions.find(d => d.id === discussion_id);
        if (discussion) {
          discussion.is_favorite = false;
        }
      });
  }
}
