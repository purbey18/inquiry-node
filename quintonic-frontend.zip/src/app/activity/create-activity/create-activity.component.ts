import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';

@Component({
  selector: 'app-create-activity',
  templateUrl: './create-activity.component.html',
  styleUrls: ['./create-activity.component.scss']
})
export class CreateActivityComponent implements OnInit {
  activeStep = 1;
  createEvent: any = {};
  eventForm = {
    stepOne: false,
    stepTwo: false,
    stepThree: false
  }
  constructor(
    private activityService: ActivityService,
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  nextStep(e: any) {
    console.log(e);
    this.createEvent = { ...this.createEvent, ...e.data };
    console.log(this.createEvent);
    this.activeStep = e.nextStep;
  }

  saveToDraft(e: any) {
    this.createEvent = { ...this.createEvent, ...e.data };
    this.activityService.organizeEvent(this.getFormData()).subscribe({
      next: res => {
        console.log(res)
      },
      error: err => {
        console.log(err)
      }
    });
  }

  publishEvent(e: any) {
    this.createEvent = { ...this.createEvent, ...e.data };
    console.log(this.createEvent);
    this.activityService.organizeEvent(this.getFormData()).subscribe({
      next: res => {
        console.log(res);
        // groupes/aix-en-provence/quia-doloribus-doloribus-non-rerum-magna-quia
        this.router.navigateByUrl(`/groupes/${res.favorite_city.slug}/${res.slug}`);
      },
      error: err => {
        console.log(err)
      }
    });
  }

  getFormData() {
    const formData = new FormData();
    const fv: any = { ...this.createEvent };
    fv.starts_at = `${fv.starts_at.year}-${fv.starts_at.month}-${fv.starts_at.day}T${fv.starts_hours}:${fv.starts_mintues}:00.000Z`;
    if (fv.ends_at) {
      fv.ends_at = `${fv.ends_at.year}-${fv.ends_at.month}-${fv.ends_at.day}T${fv.ends_hours}:${fv.ends_minutes}:00.000Z`;
    }

    for (const key in fv) {
      if (key === 'tag_ids') {
        fv[key].forEach((t: number) => {
          formData.append('tag_ids[]', t.toString());
        });
      } else {
        formData.append(key, fv[key] as any);
      }
    }
    return formData;
  }

}
