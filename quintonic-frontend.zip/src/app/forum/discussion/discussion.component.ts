import { Component, OnInit } from '@angular/core';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { FavoriteCity, IForumDiscussion } from 'src/app/shared/interfaces/common';
import { ActivatedRoute } from '@angular/router';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
@Component({
  selector: 'app-discussion',
  templateUrl: './discussion.component.html',
  styleUrls: ['./discussion.component.scss']
})
export class DiscussionComponent implements OnInit {

  discussionList: IForumDiscussion[] = [];
  filterForm: FormGroup;
  totalItems: number = 0;
  favoriteCity: FavoriteCity[] = [];
  filterObj: any = {
    created_by_me: 'created_by_me=true&order_by=last_comment',
    by_recency: 'order_by=recency',
    commented_by_me: 'commented_by_me=true',
    last_commented: 'order_by=last_comment',
    created_by_friends: 'created_by_friends=true',
    favorites: 'favorites=true&order_by=last_comment'
  };
  constructor(
    private forumService: ForumService,
    private utilService: UtilityService,
    private modalService: ModalService,
    private route: ActivatedRoute,
    private startupService: StartupService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1, []),
      per_page: new FormControl(20, []),
      theme: new FormControl(),
      favorite_city: new FormControl(),
      order_by: new FormControl(),
    });
  }

  ngOnInit(): void {
    this.favoriteCity = this.startupService.getFavCities;
    this.route.paramMap.subscribe(params => {
      const city = params.get('city');
      if (city === 'all') {
        const query = this.route.snapshot.queryParams;
        this.discussion(this.filterObj[query['quickAccess']])
      } else if (!isNaN(Number(city))) {
        this.filterForm.get('theme')?.setValue(city);
        this.filterForm.get('order_by')?.setValue('last_comment');
        this.discussion()
      } else {
        const cityId = this.favoriteCity.find(f => f.slug === city)?.id;
        this.filterForm.get('favorite_city')?.setValue(cityId);
        this.discussion()
      }
    });
  }

  discussion(q?: string) {
    const query = this.utilService.serialize(this.filterForm.value) + (q ? '&' + q : '');
    this.forumService.discussion(query).subscribe((res) => {
      this.discussionList = res.body
      this.discussionList = [...new Map(this.discussionList.map(city => [city.id, city])).values()];
      this.totalItems = res.headers.get('x-total');
    })
  }

  updatePagination(e: any) {
    this.filterForm.get('page')?.setValue(e);
    this.discussion();
  }

  displayChatModal() {
    this.modalService.createChatModel()
  }

}
