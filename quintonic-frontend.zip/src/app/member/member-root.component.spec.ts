import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberRootComponent } from './member-root.component';

describe('MemberRootComponent', () => {
  let component: MemberRootComponent;
  let fixture: ComponentFixture<MemberRootComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberRootComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
