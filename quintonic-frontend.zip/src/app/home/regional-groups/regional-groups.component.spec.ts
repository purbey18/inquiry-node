import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegionalGroupsComponent } from './regional-groups.component';

describe('RegionalGroupsComponent', () => {
  let component: RegionalGroupsComponent;
  let fixture: ComponentFixture<RegionalGroupsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegionalGroupsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegionalGroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
