import { NgModule } from '@angular/core';
import { HomeRootComponent } from './home-root.component';
import { HomeComponent } from './home/home.component';
import { HomeRoutingModule } from './home-routing.module';
import { PageInfoBlockComponent } from './components/page-info-block/page-info-block.component';
import { RegisterStepOneComponent } from './register-step-one/register-step-one.component';
import { RegisterStepTwoComponent } from './register-step-two/register-step-two.component';
import { RegisterStepThreeComponent } from './register-step-three/register-step-three.component';
import { RegisterStepsHeaderComponent } from './components/register-steps-header/register-steps-header.component';
import { SharedModule } from '../shared/shared/shared.module';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AidComponent } from './aid/aid.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { EventFaqComponent } from './event-faq/event-faq.component';
import { QuintonicIntroComponent } from './quintonic-intro/quintonic-intro.component';
import { RegionalGroupsComponent } from './regional-groups/regional-groups.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { UserCharterComponent } from './user-charter/user-charter.component';
import { LegalNoticeComponent } from './legal-notice/legal-notice.component';
import { PasswordResetComponent } from './password-reset/password-reset.component';
import { PasswordResetModalComponent } from './components/password-reset-modal/password-reset-modal.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    HomeRootComponent,
    HomeComponent,
    PageInfoBlockComponent,
    RegisterStepOneComponent,
    RegisterStepTwoComponent,
    RegisterStepThreeComponent,
    RegisterStepsHeaderComponent,
    ContactUsComponent,
    AidComponent,
    AboutUsComponent,
    EventFaqComponent,
    QuintonicIntroComponent,
    RegionalGroupsComponent,
    TermsAndConditionsComponent,
    UserCharterComponent,
    LegalNoticeComponent,
    PasswordResetComponent,
    PasswordResetModalComponent,
    NotificationsComponent
  ],
  imports: [
    HomeRoutingModule,
    SharedModule,
    NgbCollapseModule
  ]
})
export class HomeModule { }
