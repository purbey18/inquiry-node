import { Component, OnInit } from '@angular/core';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { IActivity } from '../interface/interface';
import { ACTIVITY } from '../constants/activity-constant';
import { FormGroup, FormControl } from '@angular/forms';
import { Location } from '@angular/common';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.scss']
})
export class ActivityComponent implements OnInit {
  ACTIVITY_CONST = ACTIVITY;
  themes: any = [];
  activities: IActivity[] = [];
  totalItems = 0;
  isLoading = true;
  filterForm: FormGroup;
  listMode: boolean = false;
  constructor(
    private activityService: ActivityService,
    private location: Location,
    private utilService: UtilityService,
    private route: ActivatedRoute
  ) {
    this.filterForm = new FormGroup({
      city: new FormControl('', []),
      distance: new FormControl(this.ACTIVITY_CONST.RADIUS[2].value, []),
      favorite_city_id: new FormControl('', []),
      friend_attending: new FormControl('', []),
      order_by: new FormControl('event_date_desc', []),
      page: new FormControl(1, []),
      per_page: new FormControl(18, []),
      period: new FormControl('upcoming', []),
      theme: new FormControl('', []),
      title: new FormControl('', []),
      commercial: new FormControl(''),
      status: new FormControl()
    });
  }

  setValue($event: any, controlName: string, valueLabel: string) {
    this.filterForm.get(controlName)?.setValue($event[valueLabel]);
    this.navigateTo();
  }

  ngOnInit(): void {

    const params = this.route.snapshot.queryParams;
    for (let param in params) {
      if (param !== 'city' && params[param].includes(',')) {
        this.filterForm.get(param)?.setValue(params[param].split(','));
      } else {
        this.filterForm.get(param)?.setValue(params[param]);
      }
    }
    this.load();
    this.theme();
  }

  theme() {
    this.activityService.theme()
      .subscribe(res => {
        this.themes = res;
        this.themes.unshift({ id: '', name: 'Toutes les activités' });
      });
  }

  load() {
    this.isLoading = true;
    this.activities = [];
    this.activityService.list(this.filterForm.value)
      .subscribe(res => {
        this.totalItems = res.headers.get('x-total');
        this.activities = res.body;
        this.isLoading = false;
      });
  }

  updatePagination(e: any) {
    this.filterForm.get('page')?.setValue(e);
    this.navigateTo();
  }

  navigateTo() {
    console.log(this.filterForm.value);
    const query = this.utilService.serialize(this.filterForm.value);
    console.log(query);
    this.location.replaceState("groupes/activites", query);
    this.load();
  }

  addressChanged(e: any) {
    console.log(e.formatted_address);
    this.filterForm.get('city')?.setValue(e.formatted_address);
    console.log(this.filterForm.value);
    this.navigateTo();
  }

  changeListingView() {
    this.listMode = !this.listMode;
  }

  advanceFilterUpdated(event: any) {
    console.log(event);
    for (let i in event) {
      if (i === 'whichActivities') {

        let items = [];
        for (let ii in event[i]) {
          if (event[i][ii]) {
            items.push(ii);
          }
        }
        console.log(items);
        this.filterForm.get('status')?.setValue(items);
      } else {
        this.filterForm.get(i)?.setValue(event[i]);
      }
    }
    this.navigateTo();
  }

  removeFilter(filedName: string) {
    this.filterForm.get(filedName)?.reset();
    this.navigateTo();
  }

}
