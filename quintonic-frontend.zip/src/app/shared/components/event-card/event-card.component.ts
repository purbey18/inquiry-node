import { Component, Input } from '@angular/core';
import { IActivity } from '../../../activity/interface/interface';
import { StartupService } from '../../services/startup/startup.service';
import { IUser } from '../../interfaces/common';

@Component({
  selector: 'app-event-card',
  templateUrl: './event-card.component.html',
  styleUrls: ['./event-card.component.scss']
})
export class EventCardComponent {
  @Input() activity!: IActivity;
  user!: IUser;
  constructor(private startupService: StartupService) {
    this.user = this.startupService.getUser();
  }
}
