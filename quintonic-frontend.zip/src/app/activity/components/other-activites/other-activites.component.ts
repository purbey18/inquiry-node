import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivityService } from 'src/app/shared/services/activity/activity.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { IActivity } from '../../interface/interface';
import { ITheme } from 'src/app/shared/interfaces/common';

@Component({
  selector: 'app-other-activites',
  templateUrl: './other-activites.component.html',
  styleUrls: ['./other-activites.component.scss']
})
export class OtherActivitesComponent implements OnInit {

  @Input() theme!: ITheme
  @Input() eventId!: number

  filterForm!: FormGroup;
  totalItems = 0;
  events: IActivity[] = [];

  constructor(
    private utilService: UtilityService,
    private activityService: ActivityService
  ) { }

  ngOnInit(): void {
    this.filterForm = new FormGroup({
      distance: new FormControl(100),
      exclude: new FormControl(this.eventId),
      order_by: new FormControl('event_date'),
      page: new FormControl(1),
      per_page: new FormControl(5),
      period: new FormControl('upcoming'),
      theme: new FormControl(this.theme.id)
    });
    this.otherevents()
  }

  otherevents() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.activityService.otherThemeEvents(query).subscribe((res) => {
      this.totalItems = res.headers.get('x-total');
      this.events = res.body
    })
  }

}
