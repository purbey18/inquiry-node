import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quintotv',
  templateUrl: './quintotv.component.html',
  styleUrls: ['./quintotv.component.scss']
})
export class QuintotvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
