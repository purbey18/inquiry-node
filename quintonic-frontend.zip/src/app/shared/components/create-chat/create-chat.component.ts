import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ValidationService } from '../../services/validations/validations.sevice';
import { ForumService } from '../../services/forum/forum.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FavoriteCity, ITheme } from '../../interfaces/common';

@Component({
  selector: 'app-create-chat',
  templateUrl: './create-chat.component.html',
  styleUrls: ['./create-chat.component.scss'],
})
export class CreateChatComponent implements OnInit {
  model: any;
  chatForm: FormGroup;
  constructor(
    private validationService: ValidationService,
    private forumService: ForumService,
    private fb: FormBuilder,
    public activeModal: NgbActiveModal
  ) {
    this.chatForm = this.fb.group({
      title: ['', this.validationService.minlengthValidator('title', 3)],
      favorite_city_id: [],
      theme_id: [],
      body: ['', this.validationService.minlengthValidator('body', 5)],
    });
  }

  ngOnInit(): void { }

  activitySelected(e: ITheme) {
    this.chatForm.get('theme_id')?.setValue(e.id);
  }

  citySelected(e: FavoriteCity) {
    this.chatForm.get('favorite_city_id')?.setValue(e.id);
  }

  createChat() {
    console.log(this.chatForm.value);
    this.forumService.create_chat(this.chatForm.value).subscribe((res) => {
      console.log(res);
    });
  }
}
