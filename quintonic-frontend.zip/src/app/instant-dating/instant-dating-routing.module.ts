import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InstantDatingRootComponent } from './instant-dating-root.component';
import { InstantDatingComponent } from './instant-dating/instant-dating.component';
import { MeetComponent } from './meet/meet.component';
import { TheyChooseComponent } from './they-choose/they-choose.component';
import { YouMatchComponent } from './you-match/you-match.component';

const routes: Routes = [
  {
    path: '',
    component: InstantDatingRootComponent,
    children: [{
      path: '',
      component: InstantDatingComponent
    }, {
      path: 'game',
      component: MeetComponent
    }, {
      path: 'half-matches',
      component: TheyChooseComponent
    }, {
      path: 'matches',
      component: YouMatchComponent
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InstantDatingRoutingModule { }
