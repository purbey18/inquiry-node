import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from '../../services/modal/modal.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  preSignup = false;
  constructor(
    public activeModal: NgbActiveModal,
    private modalService: ModalService
  ) { }

  ngOnInit(): void {
  }

  goToLogin() {
    this.activeModal.close();
    this.modalService.loginModal();
  }

}
