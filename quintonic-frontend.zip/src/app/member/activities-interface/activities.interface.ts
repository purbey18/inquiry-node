import { IActivity } from "src/app/activity/interface/interface"
import { FavoriteCity } from "src/app/shared/interfaces/common"

export interface Activities {
  id: number
  key: string
  parameters: any
  created_at: string
  user: User
  owner: Owner
  comment?: Comment
  discussion?: Discussion2
  event_participation?: EventParticipation
  organized_event: IActivity
  suggested_event?: SuggestedEvent
}

export interface User {
  age: number
  avatar: Avatar
  biography: any
  city: string
  created_at: string
  distance: any
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
  relationship: any
  ambassed_favorite_city: any
}

export interface Avatar {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby {
  id: number
  name: string
  theme_id: number
}

export interface Owner {
  age: number
  avatar: Avatar2
  biography: any
  city: string
  created_at: string
  distance: number
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby2[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
}

export interface Avatar2 {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby2 {
  id: number
  name: string
  theme_id: number
}

export interface Comment {
  id: number
  body: string
  has_children: boolean
  children_count: number
  created_at: string
  updated_at: string
  has_parent: boolean
  discussion: Discussion
  user: User3
  parent: any
}

export interface Discussion {
  id: number
  title: string
  body: string
  slug: string
  last_comment: LastComment
  comments_count: number
  created_at: string
  is_favorite: boolean
  is_sticky: boolean
  user: User2
  forum_theme: ForumTheme
  favorite_city: FavoriteCity
}

export interface LastComment {
  created_at: string
  user: string
}

export interface User2 {
  age: number
  avatar: Avatar3
  biography?: string
  city: string
  created_at: string
  distance: any
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby3[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
}

export interface Avatar3 {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby3 {
  id: number
  name: string
  theme_id: number
}

export interface ForumTheme {
  id: number
  name: string
  slug: string
  picture: Picture
  forum_seo_block?: string
}

export interface Picture {
  large: string
  small: string
}


export interface Picture2 {
  large: string
  small: string
}

export interface User3 {
  age: number
  avatar: Avatar4
  biography: any
  city: string
  created_at: string
  distance: any
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby4[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
}

export interface Avatar4 {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby4 {
  id: number
  name: string
  theme_id: number
}

export interface Discussion2 {
  id: number
  title: string
  body: string
  slug: string
  last_comment: LastComment2
  comments_count: number
  created_at: string
  is_favorite: boolean
  is_sticky: boolean
  user: User4
  forum_theme: ForumTheme2
  favorite_city: FavoriteCity
}

export interface LastComment2 {
  created_at: string
  user: string
}

export interface User4 {
  age: number
  avatar: Avatar5
  biography?: string
  city: string
  created_at: string
  distance: any
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby5[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
}

export interface Avatar5 {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby5 {
  id: number
  name: string
  theme_id: number
}

export interface ForumTheme2 {
  id: number
  name: string
  slug: string
  picture: Picture3
  forum_seo_block?: string
}

export interface Picture3 {
  large: string
  small: string
}

export interface Picture4 {
  large: string
  small: string
}

export interface EventParticipation {
  id: number
  status: string
  participant: Participant
  event: Event
}

export interface Participant {
  age: number
  avatar: Avatar6
  biography: any
  city: string
  created_at: string
  distance: any
  gender: string
  id: number
  mood: any
  slug: string
  updated_at: string
  user_name: string
  mutual_hobbies: any[]
  hobbies: Hobby6[]
  loves: any
  hates: any
  looking_for: any
  is_premium: boolean
}

export interface Avatar6 {
  thumb: string
  small: string
  large: string
  xlarge: string
  blurred: string
  blurred_small: string
  blurred_thumb: string
}

export interface Hobby6 {
  id: number
  name: string
  theme_id: number
}

export interface Event {
  id: number
  type: string
  slug: string
  title: string
  description: string
  additional_information: string
  gender_parity: boolean
  latitude: number
  longitude: number
  place?: string
  address: string
  address_complement: any
  city: string
  state: any
  postcode: string
  country: string
  starts_at: string
  ends_at?: string
  max_participants?: number
  participants_count: number
  interested_users_count: number
  cover_picture: CoverPicture
  privacy: any
  published: boolean
  participation_status: any
  tags: any[]
  commercial: boolean
  waiting_list_started?: boolean
}

export interface CoverPicture {
  thumb: string
  small: string
  large: string
}

export interface CoverPicture2 {
  thumb: string
  small: string
  large: string
}

export interface Theme {
  id: number
  name: string
  slug: string
  picture: Picture5
  events_seo_top_block: any
  events_seo_bottom_block: any
  meta_title: any
  meta_desc: any
}

export interface Picture5 {
  url: string
}


export interface Picture6 {
  large: string
  small: string
}
export interface SuggestedEvent {
  id: number
  type: string
  slug: string
  title: string
  description: string
  additional_information: string
  gender_parity: boolean
  latitude: number
  longitude: number
  place: any
  address: string
  address_complement: any
  city: string
  state: any
  postcode: string
  country: string
  starts_at: string
  ends_at: string
  max_participants: any
  participants_count: number
  interested_users_count: number
  cover_picture: CoverPicture3
  privacy: number
  published: boolean
  participation_status: any
  tags: any[]
  commercial: boolean
  theme: Theme2
  favorite_city: FavoriteCity
}

export interface CoverPicture3 {
  thumb: string
  small: string
  large: string
}

export interface Theme2 {
  id: number
  name: string
  slug: string
  picture: Picture7
  events_seo_top_block: any
  events_seo_bottom_block: any
  meta_title: any
  meta_desc: any
}

export interface Picture7 {
  url: string
}

export interface Picture8 {
  large: string
  small: string
}
