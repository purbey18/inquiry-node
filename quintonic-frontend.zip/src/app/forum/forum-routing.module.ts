import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForumRootComponent } from './forum-root.component';
import { ForumComponent } from './forum/forum.component';
import { DiscussionComponent } from './discussion/discussion.component';
import { DetailsComponent } from './details/details.component';

const routes: Routes = [
  {
    path: '',
    component: ForumRootComponent,
    children: [{
      path: '',
      component: ForumComponent
    },
    {
      path: 'all/:city',
      component: DiscussionComponent
    },
    {
      path: ':city/:theme/:discussion',
      component: DetailsComponent
    }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForumRoutingModule { }
