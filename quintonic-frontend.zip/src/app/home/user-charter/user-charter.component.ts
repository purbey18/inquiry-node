import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-charter',
  templateUrl: './user-charter.component.html',
  styleUrls: ['./user-charter.component.scss']
})
export class UserCharterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
