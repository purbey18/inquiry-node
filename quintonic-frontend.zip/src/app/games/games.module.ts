import { NgModule } from '@angular/core';
import { GamesRootComponent } from './games-root.component';
import { GamesComponent } from './games/games.component';
import { SharedModule } from '../shared/shared/shared.module';
import { GamesRoutingModule } from './games-routing.module';
import { DetailComponent } from './detail/detail.component';


@NgModule({
  declarations: [
    GamesRootComponent,
    GamesComponent,
    DetailComponent
  ],
  imports: [
    GamesRoutingModule,
    SharedModule
  ]
})
export class GamesModule { }



