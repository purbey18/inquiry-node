export interface IMember {
  age: number;
  avatar?: Avatar;
  biography?: string;
  city: string;
  created_at: string;
  distance: number;
  gender: string;
  id: number;
  mood: any;
  slug: string;
  updated_at: string;
  user_name: string;
  mutual_hobbies: any[];
  hobbies: Hobby[];
  loves?: string;
  hates?: string;
  looking_for: any;
  is_premium: boolean;
  relationship?: Relationship;
  ambassed_favorite_city: any;
}
export interface Relationship {
  id: number;
  status: string;
}

export interface Avatar {
  thumb: string;
  small: string;
  large: string;
  xlarge: string;
  blurred: string;
  blurred_small: string;
  blurred_thumb: string;
}

export interface Hobby {
  id: number;
  name: string;
  theme_id: number;
}

export interface IPicture {
  id: number;
  url: Url;
  user_id: number;
  likes_count: number;
  is_liked: any;
  comments_count: number;
  created_at: string;
}

export interface Url {
  original: string;
  large: string;
  small: string;
  thumb: string;
}

export interface Root2 {
  age: number;
  avatar: Avatar;
  biography?: string;
  city: string;
  created_at: string;
  distance: number;
  gender: string;
  id: number;
  mood: any;
  slug: string;
  updated_at: string;
  user_name: string;
  mutual_hobbies: any[];
  hobbies: Hobby[];
  loves: any;
  hates: any;
  looking_for: any;
  is_premium: boolean;
  relationship: any;
  ambassed_favorite_city: any;
}

export interface IFavorite {
  id: number;
  type: string;
  name: string;
}

export interface IFilter {
  'age[maximum]': number;
  'age[mimimum]': number;
  city: string;
  distance: number;
  friend_with_me: boolean;
  gender: string;
  online: boolean;
  with_mutual_events: boolean;
  with_avatar: boolean;
  born_today: boolean;
  order_by: string;
  page: number;
  per_page: number;
  user_name: string;
  'tagged_with[]': number;
}
