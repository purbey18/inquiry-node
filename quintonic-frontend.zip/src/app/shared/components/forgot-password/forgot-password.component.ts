import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { ModalService } from '../../services/modal/modal.service';
import { HomeService } from '../../services/home/home.service';
import { MESSAGE } from 'src/app/shared/constant/message.constants';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnInit {

  errorMessage: string = ''
  successMessage: string = ''
  isSubmitted: boolean = false
  fieldRequired = MESSAGE.COMMON.fieldRequired;
  invalidEmail = MESSAGE.AUTH.invalidEmail;

  constructor(
    public activeModal: NgbActiveModal,
    private modalService: ModalService,
    private homeService: HomeService,
    private router: Router
  ) { }

  forgotPassword = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  get f(): { [key: string]: AbstractControl } {
    return this.forgotPassword.controls;
  }

  ngOnInit(): void { }

  forgotSubmit() {
    this.isSubmitted = true;
    if (!this.forgotPassword.valid) return;
    const data = { ...this.forgotPassword.value, redirect_url: "https://www.whatz.fr/" }
    this.homeService.forgot(data)
      .subscribe({
        next: res => {
          this.isSubmitted = false;
          if (res.success) {
            this.errorMessage = ''
            this.successMessage = res.message
          }
          if (res.data) {
            if (!res.data.profile_completed_at) {
              this.router.navigateByUrl('/profile-completion/step-one');
            } else {
              this.router.navigateByUrl('/groupes/activites');
            }
          }
        },
        error: err => {
          console.log(err);
          this.isSubmitted = false;
          this.successMessage = ''
          this.errorMessage = err.error.errors[0]
        }
      })
  }

  goToLogin() {
    this.activeModal.close();
    this.modalService.loginModal();
  }
}
