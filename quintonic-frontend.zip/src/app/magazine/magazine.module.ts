import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared/shared.module';
import { MagazineRootComponent } from './magazine-root.component';
import { MagazineRoutingModule } from './magazine-routing.module';
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';

@NgModule({
  declarations: [
    MagazineRootComponent,
    ListComponent,
    DetailComponent
  ],
  imports: [
    MagazineRoutingModule,
    SharedModule,
  ]
})
export class MagazineModule { }
