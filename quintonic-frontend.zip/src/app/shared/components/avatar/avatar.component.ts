import { Component, Input, OnInit } from '@angular/core';
import { Avatar, IUser } from '../../interfaces/common';
import { IOrganizer } from '../../interfaces/common';
import { IMyFriends } from '../../interfaces/profile';
import { Router } from '@angular/router';

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.scss']
})
export class AvatarComponent implements OnInit {
  @Input() user!: IUser | IOrganizer | IMyFriends;
  @Input() type: 'thumb' | 'small' | 'large' | 'xlarge' | 'blurred' | 'blurred_small' | 'blurred_thumb' = 'thumb';
  @Input() class: 'proiconround' | 'profile-img' | 'profile-img large' = 'proiconround';
  @Input() showOnline = true;
  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    if (this.user.avatar === null) {
      const img = this.user.gender === "M" ? './assets/images/male_default.png' : './assets/images/female_default.png';
      this.user.avatar = {
        thumb: img,
        large: img,
        small: img        
      }
    }
  }

  goToProfile() {
    this.router.navigateByUrl(`/users/${this.user.slug}/journal`);
  }

}
