import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aid',
  templateUrl: './aid.component.html',
  styleUrls: ['./aid.component.scss']
})
export class AidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
