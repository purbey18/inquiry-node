import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from 'src/app/shared/services/user/user.service';
import { ValidationService } from 'src/app/shared/services/validations/validations.sevice';

@Component({
  selector: 'app-password-reset-modal',
  templateUrl: './password-reset-modal.component.html',
  styleUrls: ['./password-reset-modal.component.scss'],
})
export class PasswordResetModalComponent implements OnInit {
  passwordResetForm: FormGroup;
  constructor(
    public activeModal: NgbActiveModal,
    private validationService: ValidationService,
    private fb: FormBuilder,
    private userService: UserService
  ) {
    this.passwordResetForm = this.fb.group({
      password: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.minlengthValidator('password', 8),
        ],
      ],
      password_confirmation: [
        '',
        [
          this.validationService.requiredValidator(),
          this.validationService.minlengthValidator('password', 8),
        ],
      ],
    });
  }

  ngOnInit(): void {}

  passwordResetSubmit() {
    console.log(this.passwordResetForm.value);
    
    this.userService.passwordReset(this.passwordResetForm.value)
    .subscribe({
      next: async res => {
        console.log(res);
      },error: async error => {
        console.log(error);
      }
    })
  
  }
}
