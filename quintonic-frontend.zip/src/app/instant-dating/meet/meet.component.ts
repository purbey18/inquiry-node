import { Component, OnInit } from '@angular/core';
import { ITabs } from 'src/app/shared/interfaces/ui';
import { TABS } from '../constants/tabs';
import { FormControl, FormGroup } from '@angular/forms';
import { MeetUpService } from 'src/app/shared/services/meet-up/meet-up.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { IUser } from 'src/app/shared/interfaces/common';

@Component({
  selector: 'app-meet',
  templateUrl: './meet.component.html',
  styleUrls: ['./meet.component.scss'],
})
export class MeetComponent implements OnInit {
  tabs: ITabs[] = TABS;
  filterForm: FormGroup;
  settingForm: FormGroup;
  suggestions: any[] = [];

  constructor(
    private meetUpService: MeetUpService,
    private utilityService: UtilityService
  ) {
    this.filterForm = new FormGroup({
      limit: new FormControl(1),
      'excluded_ids[]': new FormControl(),
    });
    this.settingForm = new FormGroup({
      meetup_distance: new FormControl(),
      meetup_enabled: new FormControl(),
      meetup_gender: new FormControl(),
      meetup_max_age: new FormControl(),
      meetup_min_age: new FormControl(),
    });
  }

  ngOnInit(): void {
    this.tabs[0].selected = true;
    this.tabs[1].selected = false;
    this.tabs[2].selected = false;

    this.getSuggestions();
    this.meetupSetting();
  }

  getSuggestions() {
    const query = this.utilityService.serialize(this.filterForm.value);
    this.meetUpService.suggestions(query).subscribe((res) => {
      this.suggestions = res;
      console.log('suggestions :', res);
    });
  }

  meetupSetting() {
    const query = this.utilityService.serialize(this.settingForm.value);
    this.meetUpService.meetup(query).subscribe((res) => {
      console.log(res);
    });
  }

  advanceFilterUpdated(event: any) {
    console.log('Advance filter event:', event);
    for (let i in event) {
      this.settingForm.get(i)?.setValue(event[i]);
    }
    this.meetupSetting();
  }

  like(userId: number) {
    const obj = { liked: true, user_id: userId };
    this.meetUpService.play(obj).subscribe((res) => {
      console.log(res);
    });
  }

  dislike(userId: number) {
    const obj = { liked: false, user_id: userId };
    this.meetUpService.play(obj).subscribe((res) => {
      console.log(res);
    });
  }
}
