import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss'],
})
export class ContactUsComponent implements OnInit {
  loginForm: FormGroup;
  constructor() {
    this.loginForm = new FormGroup({
      firstName: new FormControl(' ', [Validators.required]),
      name: new FormControl(' ', [Validators.required]),
      phone: new FormControl(' ', [Validators.required]),
      email: new FormControl(' ', [Validators.required]),
    });
  }

  ngOnInit(): void {}
}
