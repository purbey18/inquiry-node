import { Component, OnInit, Input } from '@angular/core';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { Activities } from '../../activities-interface/activities.interface';
import { IActivity } from 'src/app/activity/interface/interface';
import { IUser } from 'src/app/shared/interfaces/common';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  @Input() userId = 0;
  user!: IUser;
  commentText = ''
  activityList: any[] = [];

  constructor(
    private memberService: MemberService,
    private startupService: StartupService,
  ) { }

  ngOnInit(): void {
    this.user = this.startupService.getUser()
    this.list()
  }

  list() {
    this.memberService.activities(this.userId).subscribe((res) => {
      this.activityList = res;
      console.log('news:', res)
    });
  }
  receive(event : any){
    this.commentText = event;
  }
  wallPost(){
    const modal = {
      message : this.commentText
    }
      this.memberService.wallPost(modal).subscribe({
        next: res=>{
          this.activityList.unshift(res);
          this.commentText = '';
        },
        error: error=>{
          console.log(error);
          
        }
      })
  }

}
