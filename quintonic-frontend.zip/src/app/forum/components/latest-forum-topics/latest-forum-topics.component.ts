import { Component, OnInit } from '@angular/core';
import { IForum } from 'src/app/forum/interface/interface';
import { ForumService } from 'src/app/shared/services/forum/forum.service';
import { UtilityService } from 'src/app/shared/services/utility/utility.service';
import { FormControl, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-latest-forum-topics',
  templateUrl: './latest-forum-topics.component.html',
  styleUrls: ['./latest-forum-topics.component.scss'],
})
export class LatestForumTopicsComponent implements OnInit {
  topics: IForum[] = [];
  filterForm: FormGroup;
  constructor(
    private ForumService: ForumService,
    private utilService: UtilityService
  ) {
    this.filterForm = new FormGroup({
      page: new FormControl(1, []),
      per_page: new FormControl(5, []),
      order_by: new FormControl('recency', []),
    });
  }

  ngOnInit(): void {
    this.load();
  }

  load() {
    const query = this.utilService.serialize(this.filterForm.value);
    this.ForumService.topics(query).subscribe((res) => {
      this.topics = res.body;
    });
  }
}
