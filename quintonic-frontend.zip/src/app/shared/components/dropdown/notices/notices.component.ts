import { Component, OnInit } from '@angular/core';
import { INotification } from 'src/app/shared/interfaces/header';
import { HeaderService } from 'src/app/shared/services/header/header.service';
import { UserService } from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-notices',
  templateUrl: './notices.component.html',
  styleUrls: ['./notices.component.scss'],
})
export class NoticesComponent implements OnInit {
  notifications: INotification[] = [];
  profileVisitCount = 0;
  constructor(
    private headerService: HeaderService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.userService.profileCount().subscribe((res) => {
      this.profileVisitCount = res;
    });
  }

  getData() {
    return this.headerService.notice().subscribe((res) => {
      this.notifications = res;
      this.notification_fetch();
    });
  }

  notification_fetch() {
    return this.headerService.notification_fetch().subscribe((res) => this.profileVisitCount = 0);
  }

  markAllRead() {
    this.userService.markProfileAsRead()
    .subscribe(res => {});
  }
}
