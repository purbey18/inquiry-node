import { Component, Input, OnInit } from '@angular/core';
import { IMember } from '../../interface/interface';
import { StartupService } from 'src/app/shared/services/startup/startup.service';
import { IUser } from 'src/app/shared/interfaces/common';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-send-request',
  templateUrl: './send-request.component.html',
  styleUrls: ['./send-request.component.scss']
})
export class SendRequestComponent implements OnInit {
  @Input() user!: IMember;
  logedInUser!: IUser;
  message: string = '';


  constructor(
    private startUpService: StartupService,
    public activeModal: NgbActiveModal,
    private memnberService: MemberService,
    private translateService: TranslateService

  ) { }

  ngOnInit(): void {
      this.logedInUser = this.startUpService.getUser();
      this.message = this.translateService.instant('friends.modals.confirmAddFriend.message' ,{user_name:this.logedInUser.user_name})
      

  }
  sendRequest(){
    
    const modal = {
      user_id : this.user.id,
      message : this.message
    }
    this.memnberService.sendFriendRequest(modal).subscribe({
      next: res=> {
        this.user.relationship = res;
        this.activeModal.dismiss();
        
      },
      error: error=>{
        console.log(error);
        
      }
    })
  }
  
}
