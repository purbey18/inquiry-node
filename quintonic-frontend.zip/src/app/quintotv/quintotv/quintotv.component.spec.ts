import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuintotvComponent } from './quintotv.component';

describe('QuintotvComponent', () => {
  let component: QuintotvComponent;
  let fixture: ComponentFixture<QuintotvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuintotvComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuintotvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
