import { Component, Input, OnInit } from '@angular/core';
import { IArtical } from 'src/app/activity/interface/interface';

@Component({
  selector: 'app-magazine-card',
  templateUrl: './magazine-card.component.html',
  styleUrls: ['./magazine-card.component.scss']
})
export class MagazineCardComponent implements OnInit {
  @Input() artical!: IArtical;
  constructor() { }

  ngOnInit(): void {
  }

}
