import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbusiveContentComponent } from './abusive-content.component';

describe('AbusiveContentComponent', () => {
  let component: AbusiveContentComponent;
  let fixture: ComponentFixture<AbusiveContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbusiveContentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AbusiveContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
