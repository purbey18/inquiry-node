import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { APP } from 'src/app/shared/constant/app.constant';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss'],
})
export class ConfirmationComponent {
  @Input() message = '';
  @Input() title = '';
  @Input() icon = '';
  @Input() cancel = '';
  @Input() confirm = '';
  @Output() confirmation: EventEmitter<any> = new EventEmitter();
  constructor(public activeModal: NgbActiveModal) {}
  ROLES = APP.CONFIRMATION;

  delete(oper: string) {
    this.confirmation.emit(oper);
    this.activeModal.dismiss();
  }
}
