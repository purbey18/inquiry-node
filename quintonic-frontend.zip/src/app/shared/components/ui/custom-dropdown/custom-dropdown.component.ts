import {
  Component,
  EventEmitter,
  forwardRef,
  Input,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-custom-dropdown',
  templateUrl: './custom-dropdown.component.html',
  styleUrls: ['./custom-dropdown.component.scss'],
})
export class CustomDropdownComponent implements OnInit {
  dropdownValue = '';
  @Input() items: any = [];
  @Input() key: string = '';
  @Input() value: string = '';
  @Input() label: string = '';
  @Input() defaultValue: string = '';
  @Output() setValue: EventEmitter<any> = new EventEmitter();

  constructor(private translateService: TranslateService) {}

  ngOnInit(): void {}

  ngOnChanges(simpleChange: SimpleChanges) {
    if (this.items.length) {
      this.label = this.items.find(
        (i: any) => i[this.value].toString() === this.defaultValue.toString()
      )?.name;
    }
  }

  sendValue(item: any) {
    this.setValue.emit(item);
  }
}
