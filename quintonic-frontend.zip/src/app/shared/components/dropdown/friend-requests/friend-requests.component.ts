import { Component } from '@angular/core';
import { UserService } from 'src/app/shared/services/user/user.service';

@Component({
  selector: 'app-friend-requests',
  templateUrl: './friend-requests.component.html',
  styleUrls: ['./friend-requests.component.scss'],
})
export class FriendRequestsComponent {
  count = 0;
  isLoading = false;
  constructor(
    private userService: UserService
  ) {
    this.userService.friendRequestCount()
      .subscribe((res) => {
        this.count = res;
      });
  }

  markAsRead() {
    this.isLoading = true;
    this.userService.friendRequestFetched()
      .subscribe(res => { });
  }
}
