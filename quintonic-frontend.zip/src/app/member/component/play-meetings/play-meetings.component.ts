import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-play-meetings',
  templateUrl: './play-meetings.component.html',
  styleUrls: ['./play-meetings.component.scss']
})
export class PlayMeetingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
