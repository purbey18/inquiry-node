import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.scss'],
})
export class TermsAndConditionsComponent implements OnInit {
  openClose = {
    first: {
      isClose: true,
      sub: {
        first: true,
        second: true,
        third: true,
        fourth: true,
      },
    },
    second: {
      isClose: true,
    },
    third: {
      isClose: true,
    },
    fourth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
      },
    },
    fifth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
      },
    },
    sixth: {
      isClose: true,
      sub: {
        first: true,
      },
    },
    seventh: {
      isClose: true,
    },
    eighth: {
      isClose: true,
    },
    ninth: {
      isClose: true,
    },
    tenth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
      },
    },
    eleventh: {
      isClose: true,
      sub: {
        first: true,
        second: true,
      },
    },
    twelfth: {
      isClose: true,
    },
    thirteenth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
        third: true,
        fourth: true,
        fifth: true,
      },
    },
    fourteenth: {
      isClose: true,
    },
    fifteenth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
        third: true,
        fourth: true,
      },
    },
    sixteenth: {
      isClose: true,
    },
    seventeenth: {
      isClose: true,
      sub: {
        first: true,
        second: true,
        third: true,
        fourth: true,
      },
    },
    eighteenth: {
      isClose: true,
    },
    nineteenth: {
      isClose: true,
    },
  };
  constructor() {}

  ngOnInit(): void {}
}
