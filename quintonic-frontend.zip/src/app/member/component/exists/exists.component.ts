import { Component, OnInit, Input } from '@angular/core';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { IActivity } from 'src/app/activity/interface/interface';

@Component({
  selector: 'app-exists',
  templateUrl: './exists.component.html',
  styleUrls: ['./exists.component.scss']
})
export class ExistsComponent implements OnInit {

  @Input() userId = 0;
  eventList: IActivity[] = [];

  constructor(
    private memberService: MemberService,
  ) { }

  ngOnInit(): void {
    this.list()
  }

  list() {
    this.memberService.exists(this.userId).subscribe((res) => {
      this.eventList = res
      console.log('events:', res);
    })
  }
}
