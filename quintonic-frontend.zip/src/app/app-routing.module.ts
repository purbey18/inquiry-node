import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
  }, {
    path: 'groupes',
    loadChildren: () => import('./activity/activity.module').then(m => m.ActivityModule)
  }, {
    path: 'quintotv_presentation',
    loadChildren: () => import('./quintotv/quintotv.module').then(m => m.QuintotvModule)
  }, {
    path: 'meetup',
    loadChildren: () => import('./instant-dating/instant-dating.module').then(m => m.InstantDatingModule)
  }, {
    path: 'magazine',
    loadChildren: () => import('./magazine/magazine.module').then(m => m.MagazineModule)
  }, {
    path: 'forum',
    loadChildren: () => import('./forum/forum.module').then(m => m.ForumModule)
  }, {
    path: 'games',
    loadChildren: () => import('./games/games.module').then(m => m.GamesModule)
  }, {
    path: 'users',
    loadChildren: () => import('./member/member.module').then(m => m.MemberModule)
  }, {
    path: 'billing/subscription/new',
    loadChildren: () => import('./subscription/subscription.module').then(m => m.SubscriptionModule)
  }, {
    path: 'search',
    loadChildren: () => import('./search/search.module').then(m => m.SearchModule)
  }, {
    path: 'user-account',
    loadChildren: () => import('./user-account/user-account.module').then(m => m.UserAccountModule)
  }, {
    path: 'friends',
    loadChildren: () => import('./friend/friend.module').then(m => m.FriendModule)
  }, {
    path: 'chat',
    loadChildren: () => import('./chat/chat.module').then(m => m.ChatModule)
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }