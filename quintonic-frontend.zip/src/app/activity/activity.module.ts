import { NgModule } from '@angular/core';
import { ActivityRootComponent } from './activity-root.component';
import { ActivityRoutingModule } from './activity-routing.module';
import { ActivityComponent } from './activity/activity.component';
import { SharedModule } from '../shared/shared/shared.module';
import { SuggestActivityComponent } from './components/suggest-activity/suggest-activity.component';
import { StepOneComponent } from './add-activity/step-one/step-one.component';
import { StepTwoComponent } from './add-activity/step-two/step-two.component';
import { StepThreeComponent } from './add-activity/step-three/step-three.component';
import { ActivityContentComponent } from './activity-content/activity-content.component';
import { AdvanceSearchComponent } from './components/advance-search/advance-search.component';
import { LatestPostActivityComponent } from './components/latest-post-activity/latest-post-activity.component';
import { LastMinuteComponent } from './components/last-minute/last-minute.component';
import { DetailComponent } from './detail/detail.component';
import { ConfirmParticipationComponent } from './components/confirm-participation/confirm-participation.component';
import { CreateActivityComponent } from './create-activity/create-activity.component';
import { SendInvitationComponent } from './components/send-invitation/send-invitation.component';
import { OtherOrganizerEventComponent } from './components/other-organizer-event/other-organizer-event.component';
import { OtherActivitesComponent } from './components/other-activites/other-activites.component';
@NgModule({
  declarations: [
    ActivityRootComponent,
    ActivityComponent,
    SuggestActivityComponent,
    StepOneComponent,
    StepTwoComponent,
    StepThreeComponent,
    ActivityContentComponent,
    AdvanceSearchComponent,
    LatestPostActivityComponent,
    LastMinuteComponent,
    DetailComponent,
    ConfirmParticipationComponent,
    CreateActivityComponent,
    SendInvitationComponent,
    OtherOrganizerEventComponent,
    OtherActivitesComponent
  ],
  imports: [
    ActivityRoutingModule,
    SharedModule,
  ]
})
export class ActivityModule { }
