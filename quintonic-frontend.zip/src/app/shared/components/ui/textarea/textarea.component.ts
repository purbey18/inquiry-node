import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, SimpleChange, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.scss']
})
export class TextareaComponent implements OnInit {
  @Input() appAutoFocus = false;
  @Input() formGroup!: FormGroup;
  @Input() control!: any;
  @Input() id = '';
  @Input() name: string = this.id || '';
  @Input() placeholder = '';
  @Input() label = '';
  @Input() errorMessage: string | boolean | null = null;
  @Input() extraClass: string | string[] = '';
  @Input() maxLength = 15;
  @Input() minLength = 0;

  @Output() onBlur: EventEmitter<boolean>;
  @Output() onInput: EventEmitter<any>;

  objectFn = Object;

  constructor(
    private ref: ChangeDetectorRef
  ) {
    this.onBlur = new EventEmitter();
    this.onInput = new EventEmitter();
  }

  ngOnInit() { }

  blur() {
    this.onBlur.emit(true);
  }

  input(e: any) {
    this.onInput.emit(e);
  }

}
