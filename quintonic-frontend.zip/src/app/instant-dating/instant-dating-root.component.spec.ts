import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantDatingRootComponent } from './instant-dating-root.component';

describe('InstantDatingRootComponent', () => {
  let component: InstantDatingRootComponent;
  let fixture: ComponentFixture<InstantDatingRootComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstantDatingRootComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstantDatingRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
