import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MagazineRootComponent } from './magazine-root.component';

describe('MagazineRootComponent', () => {
  let component: MagazineRootComponent;
  let fixture: ComponentFixture<MagazineRootComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MagazineRootComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MagazineRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
