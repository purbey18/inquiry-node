import { Component, Input, OnInit } from '@angular/core';
import { IPicture } from '../../interface/interface';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { ModalService } from 'src/app/shared/services/modal/modal.service';

@Component({
  selector: 'app-pictures',
  templateUrl: './pictures.component.html',
  styleUrls: ['./pictures.component.scss']
})
export class PicturesComponent implements OnInit {

  @Input() userId = 0;
  pictures: IPicture[] = [];

  constructor(
    private memberService: MemberService,
    private modalService: ModalService
  ) { }

  ngOnInit(): void {
    this.pictureList()
  }
  viewPhoto(index: number, picId: number) {
    this.modalService.previewPhoto(this.pictures, index, picId)
  }

  pictureList() {
    this.memberService.pictures(this.userId).subscribe((res) => {
      this.pictures = res
      console.log('pictures:', res)
    })
  }
  doSomething(event : any){
    event.stopPropagation();
  }
}
