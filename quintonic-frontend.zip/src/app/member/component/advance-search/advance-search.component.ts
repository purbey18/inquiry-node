import { Options } from '@angular-slider/ngx-slider';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MemberService } from 'src/app/shared/services/member/member.service';
import { IMember } from '../../interface/interface';
import { HomeService } from 'src/app/shared/services/home/home.service';
import { ITag } from 'src/app/activity/interface/interface';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss']
})
export class AdvanceSearchComponent implements OnInit {
  searchInterest = ''
  searchMemberTerm = ''
  members: IMember[] = [];
  tagSuggestionList: ITag[] = [];
  selectedInterest: ITag[] = []
  hobbyList: ITag[] = [];
  minValue: number = 45;
  maxValue: number = 99;
  options: Options = {
    floor: 45,
    ceil: 99
  };
  advanceFilter = {
    'age[maximum]': this.maxValue,
    'age[minimum]': this.minValue,
    'tagged_with[]': this.selectedInterest,
    friend_with_me: false,
    online: false,
    with_mutual_events: false,
    born_today: false,
    with_avatar: false
  }
  @Output() advanceFilterUpdated: EventEmitter<any> = new EventEmitter();

  constructor(
    private memberService: MemberService,
    private homeService: HomeService,
  ) { }

  ngOnInit(): void {
    this.hobbies()
  }

  doAdvanceSearch() {
    this.advanceFilterUpdated.emit(this.advanceFilter);
  }

  onSliderChange(e: any): void {
    this.advanceFilter['age[maximum]'] = e.highValue;
    this.advanceFilter['age[minimum]'] = e.value;
  }

  searchMembers() {
    this.memberService.search_member(this.searchMemberTerm).subscribe((res) => {
      this.members = res
    })
  }

  hobbies() {
    this.memberService.hobbies().subscribe((res) => {
      this.hobbyList = res
    })
  }

  searchTags() {
    this.homeService.searchTag(this.searchInterest).subscribe((response: any) => {
      this.tagSuggestionList = response
    })
  }

  addInterest(tag: ITag) {
    const index = this.hobbyList.findIndex(hobbyTag => hobbyTag.id === tag.id);
    if (index !== -1) this.hobbyList.splice(index, 1);
    if (!this.selectedInterest.some(selectedTag => selectedTag.id === tag.id)) this.selectedInterest.push(tag);
    this.searchInterest = '';
  }

  removeInterest(index: number) {
    this.selectedInterest.splice(index, 1);
  }
}
